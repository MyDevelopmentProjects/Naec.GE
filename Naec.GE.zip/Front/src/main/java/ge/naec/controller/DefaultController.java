package ge.naec.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/default")
public class DefaultController {


    @RequestMapping("/layout")
    public String getTemplate() {
        return "default/default";
    }

    @RequestMapping("/contact")
    public String contact() {
        return "contact/contact";
    }

    @RequestMapping("/noIE")
    public String notIE() {
        return "default/noIE";
    }

    @RequestMapping("/noslider")
    public String getTemplate2() {
        return "default/defnoslider";
    }
}