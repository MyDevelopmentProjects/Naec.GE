package ge.naec.controller;

import ge.naec.model.Menu;
import ge.naec.service.MenuService;
import ge.naec.utils.MainUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.STRING_EMPTY;


@Controller
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;

    @RequestMapping(value = "/getByLang")
    @ResponseBody
    public List<Menu> getMenuByLang(@CookieValue(value="lang", defaultValue="ge") String lang) {
        return menuService.getMenuByLang(MainUtils.isEnglish(lang));
    }

}
