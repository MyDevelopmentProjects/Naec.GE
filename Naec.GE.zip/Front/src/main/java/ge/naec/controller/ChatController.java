package ge.naec.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/chat")
public class ChatController {

    @RequestMapping("/layout")
    public String getTemplate() {
        return "chat/chat";
    }

}
