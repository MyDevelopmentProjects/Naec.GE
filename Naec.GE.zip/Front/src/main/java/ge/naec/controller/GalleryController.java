package ge.naec.controller;

import ge.naec.dto.GalleryDTO;
import ge.naec.service.GalleryService;
import ge.naec.utils.MainUtils;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.Keys.*;
import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.SLASH;
import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/gallery")
public class GalleryController {

    @Autowired
    private GalleryService galleryService;

    @RequestMapping("/photos")
    public String getPhotoTemplate() {
        return "gallery/photo";
    }

    @RequestMapping("/videos")
    public String getVideoTemplate() {
        return "gallery/video";
    }

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<GalleryDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize,
            @RequestParam(required = false, defaultValue = "false") boolean isVideo,
            @CookieValue(value="lang", defaultValue="ge") String lang


    ) {
        return galleryService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize, isVideo, MainUtils.isEnglish(lang));

    }

}

