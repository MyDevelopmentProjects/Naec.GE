package ge.naec.controller;

import ge.naec.dto.CategoriesDTO;
import ge.naec.service.CategoriesService;
import ge.naec.utils.MainUtils;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.Keys.*;
import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.SLASH;
import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/categories")
public class CategoriesController {
    @Autowired
    private CategoriesService categoriesService;

    @RequestMapping("/layout")
    public String getTemplate() {
        return "category/category";
    }

    @RequestMapping("/layout2")
    public String getTemplate2() {
        return "category/category2";
    }

    @RequestMapping("/layout3")
    public String getTemplate3() {
        return "category/category3";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize,
            @CookieValue(value="lang", defaultValue="ge") String lang
    ) {
        return categoriesService.getList(searchExpression, sortField, isAscending, pageNumber, -255, MainUtils.isEnglish(lang));
    }
}