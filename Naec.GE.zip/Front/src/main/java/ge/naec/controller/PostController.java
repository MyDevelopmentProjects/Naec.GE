package ge.naec.controller;

import ge.naec.dto.PostDTO;
import ge.naec.model.Post;
import ge.naec.service.PostService;
import ge.naec.utils.MainUtils;
import ge.naec.utils.codeconstants.Constants;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.Keys.*;
import static ge.naec.utils.codeconstants.Constants.CustomCodeConstants.STRING_EMPTY;


@Controller
@RequestMapping("/post")
public class PostController {

    @Autowired
    private PostService postService;

    @RequestMapping("/post")
    public String getPostTemplate() {
        return "post/post";
    }

    @RequestMapping(value="/fb/{id}", method = RequestMethod.GET)
    public String processForm(HttpServletRequest request, @PathVariable("id") int id)
    {
        String redirectUrl = null;
        try {
            redirectUrl = getURLBase(request) + "/#/ge/post/" + id;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return "redirect:" + redirectUrl;
    }

    public String getURLBase(HttpServletRequest request) throws MalformedURLException {

        URL requestURL = new URL(request.getRequestURL().toString());
        String port = requestURL.getPort() == -1 ? "" : ":" + requestURL.getPort();
        return requestURL.getProtocol() + "://" + requestURL.getHost() + port;

    }

    @RequestMapping("/all")
    public String getAllPostsTemplate() {
        return "post/all";
    }


    @RequestMapping(value = "/getById/{postId}")
    @ResponseBody
    public List<Post> getArticleById(@PathVariable("postId") Long postId) {
        return postService.getPostById(postId);
    }

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<PostDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize,
            @RequestParam(required = false, defaultValue = "false") boolean hidden,
            @RequestParam(required = false, defaultValue = "0") Long categoryId,
            @CookieValue(value="lang", defaultValue="ge") String lang
    ) {
        return postService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize, hidden, categoryId, MainUtils.isEnglish(lang));
    }

    @RequestMapping(value = "/getLast10Records", method = RequestMethod.GET)
    @ResponseBody
    public List<Post> getLast10Records(@CookieValue(value="lang", defaultValue="ge") String lang) {
        return postService.getLast10Records(MainUtils.isEnglish(lang));
    }

    @RequestMapping(value = "/getTopNews", method = RequestMethod.GET)
    @ResponseBody
    public Post getTopNews(@CookieValue(value="lang", defaultValue="ge") String lang) {
        return postService.getTopNews(MainUtils.isEnglish(lang));
    }

    @RequestMapping(value = "/get6RandomNews", method = RequestMethod.GET)
    @ResponseBody
    public List<Post> get6RandomNews(@CookieValue(value="lang", defaultValue="ge") String lang) {
        return postService.get6RandomNews(MainUtils.isEnglish(lang));
    }

    @RequestMapping(value = "/getSpecialPosts", method = RequestMethod.GET)
    @ResponseBody
    public List<Post> getSpecialPosts(@CookieValue(value="lang", defaultValue="ge") String lang) {
        return postService.getSpecialPosts(MainUtils.isEnglish(lang));
    }

}
