package ge.naec.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/account")
public class LoginController {
    @RequestMapping("/layout")
    public String goToLogin() {
        return "account/signin";
    }

    @RequestMapping("/register")
    public String goToRegister() {
        return "login/register";
    }
}