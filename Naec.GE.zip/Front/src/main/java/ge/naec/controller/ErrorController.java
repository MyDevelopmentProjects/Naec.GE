package ge.naec.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by Butqucha on 10/16/15.
 */
@Controller
@RequestMapping("/error")
public class ErrorController {
    @RequestMapping("/layout")
    public String getTemplate() {
        return "error/error";
    }
}
