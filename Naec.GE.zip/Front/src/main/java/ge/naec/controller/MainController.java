package ge.naec.controller;

import ge.naec.utils.codeconstants.Constants;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class MainController {

    @RequestMapping(value = {"/"}, method = RequestMethod.GET)
    public ModelAndView welcomePage() {

        ModelAndView model = new ModelAndView();
        model.addObject("title", "Spring Security Custom Login Form");
        model.addObject("message", "This is welcome page!");
        model.setViewName("index");
        return model;

    }

    @RequestMapping(value = Constants.CustomCodeConstants.SLASH + Constants.CustomCodeConstants.LOGIN, method = RequestMethod.GET)
    public ModelAndView login(String error, String logout) {
        ModelAndView model = new ModelAndView();
        if (error != null) {
            model.addObject(Constants.CustomCodeConstants.ERROR, Constants.ErrorCodes.INVALID_USERNAME_OR_PASSWORD);
        }
        if (logout != null) {
            model.addObject(Constants.CustomCodeConstants.MSG, Constants.SuccessMessages.LOGGED_OUT_SUCCESSFULLY);
        }
        model.setViewName("index");
        return model;
    }

}