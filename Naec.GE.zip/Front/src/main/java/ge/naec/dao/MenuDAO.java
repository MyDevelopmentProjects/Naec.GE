package ge.naec.dao;

import ge.naec.model.Menu;
import ge.naec.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Repository
public class MenuDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        return new ArrayList<String>();
    }

    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {
        return null;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }


    public List<Menu> getMenuByLang(boolean isEnglish) {
        List<Menu> menu = em.createQuery("from Menu WHERE english = :isEnglish AND active = true")
                .setParameter("isEnglish", isEnglish)
                .getResultList();
        if (menu != null && menu.size() > 0) {
            return menu;
        }
        return new ArrayList<>(0);
    }

}