package ge.naec.dao;

import ge.naec.model.Post;
import ge.naec.model.Slider;
import ge.naec.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class SliderDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {

        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Slider> criteriaQuery = criteriaBuilder.createQuery(Slider.class);
        Root<Slider> returnClassRoot = criteriaQuery.from(Slider.class);
        returnClassRoot.alias(TABLE_ALIAS);
        boolean english = false;
        if (objects != null && objects.length > 0 && objects[0] instanceof Boolean) {
            english = (Boolean) objects[0];
        }
        return criteriaBuilder.equal(returnClassRoot.get("english"), english ? 1 : 0);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Slider.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}