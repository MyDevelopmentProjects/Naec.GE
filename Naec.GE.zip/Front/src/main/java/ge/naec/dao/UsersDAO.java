package ge.naec.dao;

import ge.naec.model.Users;
import ge.naec.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UsersDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @SuppressWarnings("unchecked")
    public Users findByUserName(String username) {
        List<Users> users;
        users = em.createQuery("from Users where userName=:username")
                .setParameter("username", username)
                .getResultList();
        if (users != null && users.size() > 0) {
            return users.get(0);
        }
        return null;
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Users.class) {
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }
}