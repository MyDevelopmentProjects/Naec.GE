package ge.naec.dao;

import ge.naec.model.Categories;
import ge.naec.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CategoriesDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {
        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Categories> criteriaQuery = criteriaBuilder.createQuery(Categories.class);
        Root<Categories> returnClassRoot = criteriaQuery.from(Categories.class);
        returnClassRoot.alias(TABLE_ALIAS);
        boolean english = false;
        if (objects != null && objects.length > 0 && objects[0] instanceof Boolean) {
            english = (Boolean) objects[0];
        }

        Predicate enFilter = criteriaBuilder.equal(returnClassRoot.get("english"), english ? 1 : 0);
        Predicate visibleFilter = criteriaBuilder.equal(returnClassRoot.get("visible"), 1);

        return criteriaBuilder.and(enFilter, visibleFilter);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Categories.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}