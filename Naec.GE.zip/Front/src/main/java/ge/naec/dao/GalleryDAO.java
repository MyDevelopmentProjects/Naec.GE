package ge.naec.dao;

import ge.naec.model.Gallery;
import ge.naec.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class GalleryDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Gallery save(Gallery gallery) {
        if (gallery.getId() != null) {
            em.merge(gallery);
        } else {
            em.persist(gallery);
        }
        return gallery;
    }

    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {
        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Gallery> criteriaQuery = criteriaBuilder.createQuery(Gallery.class);
        Root<Gallery> returnClassRoot = criteriaQuery.from(Gallery.class);
        returnClassRoot.alias(TABLE_ALIAS);
        boolean isVideo = false;
        if (objects != null && objects.length > 0 && objects[0] instanceof Boolean) {
            isVideo = (Boolean) objects[0];
        }
        boolean english = false;
        if (objects != null && objects.length > 1 && objects[1] instanceof Boolean) {
            english = (Boolean) objects[1];
        }
        Predicate enFilter = criteriaBuilder.equal(returnClassRoot.get("english"), english ? 1 : 0);
        Predicate videoFilter = criteriaBuilder.equal(returnClassRoot.get("video"), isVideo);
        return criteriaBuilder.and(enFilter, videoFilter);
    }

    public void delete(Long id) {
        Gallery gallery = em.find(Gallery.class, id);
        em.remove(gallery);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        return new ArrayList<>();
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}