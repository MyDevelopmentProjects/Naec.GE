package ge.naec.utils;

import ge.naec.security.MyUserDetailsService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public class MainUtils {

    private static Authentication getCurrentLoggedInUser() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    public static boolean getCurrentUser() {
        boolean authenticated = false;
        Authentication auth = getCurrentLoggedInUser();
        if (auth != null) {
            try {
                if (auth.getPrincipal().getClass().getCanonicalName().equals("ge.naec.security.MyUserDetailsService.UserRepositoryUserDetails")) {
                    authenticated = true;
                } else if (auth.getPrincipal() instanceof String) {
                    String principal = (String) auth.getPrincipal();
                    if (principal != null
                            && principal.length() > 0 && !principal.equals("anonymousUser")) {
                        authenticated = true;
                    }
                }
            } catch (Exception e) {
                authenticated = false;
            }
        }
        return authenticated;
    }

    public static boolean isEnglish(String lang){
        return lang != null && lang.equals("en");
    }

}
