package ge.naec.utils.codeconstants;

import java.io.File;

/**
 * Created by TuraMan on 5/13/2015.
 */
public class Constants {

    public static final String CATALINA_BASE_FRONT = System.getProperty("catalina.base")
            + File.separator + "webapps" + File.separator + "pp-front";
    public static final String CATALINA_BASE_BACK = System.getProperty("catalina.base")
            + File.separator + "webapps" + File.separator + "pp-admin";
    public static final String WEB_INF = CATALINA_BASE_FRONT + File.separator + "WEB-INF";
    public static final String RESOURCES = CATALINA_BASE_FRONT + File.separator + "resources";
    public static final String FRONT_UPLOADS = CATALINA_BASE_FRONT + File.separator + "resources" + File.separator + "uploads";
    public static final String RESOURCES_BACK = CATALINA_BASE_BACK + File.separator + "resources";
    public static final String CURRENT_SITE_RESOURCES = CATALINA_BASE_FRONT + File.separator + "resources" + File.separator + "%s";
    public static final String VIEWS = WEB_INF + File.separator + "views";
    public static final String TEMPLATES = VIEWS + File.separator + "templates";
    public static final String CURRENT_SITE = TEMPLATES + File.separator + "%s";
    public static final String UI = "ui";
    public static final String DESIGN_PART = "design";
    public static final String TMP_DIR = System.getProperty("catalina.base")
            + File.separator + "TMP_DIR";
    public static final String TMP_DIR_FOR_CURR_SITE = System.getProperty("catalina.base")
            + File.separator + "TMP_DIR" + File.separator + "%s";

    /**
     * Error Code Constants.
     * Starting from 1000 till 2000
     */
    public static final class ErrorCodes {
        public static final int INVALID_USERNAME_OR_PASSWORD = 1000;
        public static final int YOU_DO_NOT_HAVE_PERMISSION_TO_PERFORM_THIS_ACTION = 1001;

        public class ErrorResponse {
            public static final String EMPTY_NOT_ALLOWED = "parameter could not be empty";
        }
    }

    /**
     * SuccessMessages Code Constants.
     * Starting from 2000 till 3000
     */
    public static final class SuccessMessages {
        public static final int LOGGED_OUT_SUCCESSFULLY = 3000;
        public static final int OPERATION_COMPLETED_SUCCESSFULLY = 3001;
    }

    /**
     * CustomCodeConstants code Constants
     * This class contains all the string constants, needed in the classes while coding something
     */
    public static final class CustomCodeConstants {

        public static final String ERROR = "error";
        public static final String LOGIN = "login";
        public static final String LOGOUT = "logout";
        public static final String SLASH = "/";
        public static final String MSG = "msg";
        public static final String RESOURCES_ALL = "/resources/**";
        public static final String STRING_EMPTY = "";

        public static class Keys {
            public static final String PAGE_NUMBER = "pageNumber";
            public static final String PAGE_NUMBER_DEFAULT_VALUE = "0";
            public static final String PAGE_SIZE_DEFAULT_VALUE = "10";
            public static final String IS_ASCENDING_DEFAULT_VALUE = "true";
            public static final String LIST = "list";
        }
    }

    public static final class HTTPCodes {
        public static final int HTTP_OK = 200;
        public static final int HTTP_UNAUTHORIZED = 401;
        public static final int HTTP_BAD_REQUEST = 400;
        public static final int HTTP_NOTFOUND = 404;
        public static final int HTTP_TIMEOUT = 408;
        public static final int HTTP_CANT_CONTACT_SERVER = 407;
        public static final int HTTP_SERVER_ERROR = 500;
        public static final int DEFTIMEOUT = 60;
        public static final int DEFREFCOUNT = 10;
        public static final int DEFRETRYPERIOD = 30;
    }

    public static final class MetaConstants {

        public static final String ID = "id";
        public static final String SITE_ID = "siteId";
        public static final String NG_MODEL = "ng-model";
        public static final String NAME = "name";
        public static final String TYPE = "type";
        public static final String PLACE_HOLDER = "placeholder";
        public static final String REQUIRED = "required";
        public static final String VISIBILITY = "visibility";
        public static final String MIN_LENGTH = "minlength";
        public static final String MAX_LENGTH = "maxlength";
        public static final String ENG = "ENG";
        public static final String GEO = "GEO";
        public static final String RUS = "RUS";
        public static final String FIELDS = "fields";
        public static final String LANGUAGE = "language";
        public static final String FORM_DATA = "formData";
        public static final String VALUE = "value";
        public static final String CONTACT = "contact";
        public static final String PRODUCT = "product";
        public static final String ARTICLE = "article";
        public static final String ABOUT = "about";


        public static final class Product {
            public static final String JSON = "{\"language\":{\"GEO\":[{\"key\":\"price-name\",\"value\":\"ფასი\"},{\"key\":\"itemPrice\",\"value\":\"0\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}],\"ENG\":[{\"key\":\"price-name\",\"value\":\"Price\"},{\"key\":\"itemPrice\",\"value\":\"0\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}],\"RUS\":[{\"key\":\"price-name\",\"value\":\"цена\"},{\"key\":\"itemPrice\",\"value\":\"0\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}]},\"type\":\"product\"}";
        }

        public static final class Article {
            public static final String JSON = "{\"language\":{\"GEO\":[{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}],\"ENG\":[{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}],\"RUS\":[{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}]},\"type\":\"article\"}";
        }

        public static final class About {
            public static final String JSON = "{\"language\":{\"GEO\":[{\"key\":\"m-title-1\",\"value\":\"\"},{\"key\":\"m-title-2\",\"value\":\"\"},{\"key\":\"m-title-3\",\"value\":\"\"},{\"key\":\"slide-title-1\",\"value\":\"\"},{\"key\":\"slide-title-2\",\"value\":\"\"},{\"key\":\"slide-title-2-desc\",\"value\":\"\"},{\"key\":\"slide-title-2-desc\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}],\"ENG\":[{\"key\":\"m-title-1\",\"value\":\"\"},{\"key\":\"m-title-2\",\"value\":\"\"},{\"key\":\"m-title-3\",\"value\":\"\"},{\"key\":\"slide-title-1\",\"value\":\"\"},{\"key\":\"slide-title-2\",\"value\":\"\"},{\"key\":\"slide-title-2-desc\",\"value\":\"\"},{\"key\":\"slide-title-2-desc\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}],\"RUS\":[{\"key\":\"m-title-1\",\"value\":\"\"},{\"key\":\"m-title-2\",\"value\":\"\"},{\"key\":\"m-title-3\",\"value\":\"\"},{\"key\":\"slide-title-1\",\"value\":\"\"},{\"key\":\"slide-title-2\",\"value\":\"\"},{\"key\":\"slide-title-2-desc\",\"value\":\"\"},{\"key\":\"slide-title-2-desc\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"},{\"key\":\"\",\"value\":\"\"}]},\"type\":\"about\"}";
        }

        public static final class Contact {
            public static final String JSON = "{\"language\":{\"GEO\":[{\"key\":\"contact\",\"value\":\"კონტაქტი\"},{\"key\":\"location\",\"value\":\"ლოკაცია\"},{\"key\":\"tel-number\",\"value\":\"ტელეფონის ნომერი\"},{\"key\":\"address\",\"value\":\"მისამართი\"},{\"key\":\"tel\",\"value\":\"ტელ\"},{\"key\":\"post\",\"value\":\"ფოსტა\"},{\"key\":\"emailaddr\",\"value\":\"test@naec.ge\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"name\",\"value\":\"სახელი\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"email\",\"value\":\"შეიყვანეთ ელ-ფოსტა\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"phone\",\"value\":\"შეიყვანეთ ტელეფონი\",\"required\":\"true\"},{\"type\":\"textarea\",\"key\":\"message\",\"value\":\"შეიყვანეთ ტექსტი\",\"required\":\"true\"}],\"ENG\":[{\"key\":\"contact\",\"value\":\"Contact\"},{\"key\":\"location\",\"value\":\"Location\"},{\"key\":\"tel-number\",\"value\":\"Tel Number\"},{\"key\":\"address\",\"value\":\"Address\"},{\"key\":\"tel\",\"value\":\"Tel\"},{\"key\":\"post\",\"value\":\"Email\"},{\"key\":\"emailaddr\",\"value\":\"FORM: Enter Email PlaceHolder\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"name\",\"value\":\"FORM: Enter Name PlaceHolder\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"email\",\"value\":\"FORM: Enter EMail PlaceHolder\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"phone\",\"value\":\"FORM: Enter Phone NumberVal PlaceHolder\",\"required\":\"true\"},{\"type\":\"textarea\",\"key\":\"message\",\"value\":\"FORM: Enter Message Val PlaceHolder\",\"required\":\"true\"}],\"RUS\":[{\"key\":\"contact\",\"value\":\"Contact\"},{\"key\":\"location\",\"value\":\"Location\"},{\"key\":\"tel-number\",\"value\":\"Tel Number\"},{\"key\":\"address\",\"value\":\"Address\"},{\"key\":\"tel\",\"value\":\"Tel\"},{\"key\":\"post\",\"value\":\"Email\"},{\"key\":\"emailaddr\",\"value\":\"FORM: Enter Email PlaceHolder\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"name\",\"value\":\"FORM: Enter Name PlaceHolder\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"email\",\"value\":\"FORM: Enter EMail PlaceHolder\",\"required\":\"true\"},{\"type\":\"input\",\"key\":\"phone\",\"value\":\"FORM: Enter Phone NumberVal PlaceHolder\",\"required\":\"true\"},{\"type\":\"textarea\",\"key\":\"message\",\"value\":\"FORM: Enter Message Val PlaceHolder\",\"required\":\"true\"}]},\"type\":\"contact\"}";
        }
    }
}
