package ge.naec.model;

import com.sun.istack.internal.NotNull;
import org.hibernate.validator.constraints.Email;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;

@Entity
@Table(name = "users", catalog = "naec")
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(min = 2, max = 16)
    @Column(name = "username", unique = true, nullable = false)
    private String userName;

    @NotNull
    @Size(min = 2, max = 16)
    @Column(name = "password", nullable = false)
    private String password;

    @NotNull
    @Size(min = 2, max = 20)
    @Column(name = "first_name")
    private String firstName;

    @NotNull
    @Size(min = 2, max = 20)
    @Column(name = "last_name")
    private String lastName;

    @NotNull
    @Size(min = 4, max = 50)
    @Email
    @Column(name = "email")
    private String email;

    @NotNull
    @Column(name = "dob", nullable = false, columnDefinition = "TIMESTAMP")
    private Date dob;

    @NotNull
    @Size(min = 8, max = 20)
    @Column(name = "pid")
    private String pid;

    @NotNull
    @Size(min = 7, max = 13)
    @Column(name = "phone")
    private String phone;

    @Column(name = "is_active", columnDefinition = "bit(1) DEFAULT 0")
    private boolean active = false;

    public Users() {
    }

    public Users(Users user) {
        this.id = user.id;
        this.userName = user.userName;
        this.password = user.password;
        this.email = user.email;
        this.firstName = user.firstName;
        this.lastName = user.lastName;
        this.phone = user.phone;
        this.dob = user.dob;
        this.pid = user.pid;
        this.active = user.active;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

}
