package ge.naec.model;

import ge.naec.mappedsupperclass.SuperModel;

import javax.persistence.*;

@Entity
@Table(name = "categories", catalog = "naec")
public class Categories extends SuperModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name", columnDefinition = "VARCHAR(50) COLLATE utf8mb4_unicode_ci", nullable = false)
    private String name;

    @Column(name = "image", nullable = false)
    private String image;

    @Column(name = "video", nullable = true)
    private String video;

    @Column(name = "is_english", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean english = false;

    @Column(name = "is_visible", nullable = false, columnDefinition = "bit(1) DEFAULT 1")
    private boolean visible = true;

    /*************************************Getters & Setters***************************************************/
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public String getVideo() {
        return video;
    }
    public void setVideo(String video) {
        this.video = video;
    }
    public boolean getEnglish() {
        return english;
    }
    public void setEnglish(boolean english) {
        this.english = english;
    }

    public boolean getVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    /*************************************Getters & Setters***************************************************/
}
