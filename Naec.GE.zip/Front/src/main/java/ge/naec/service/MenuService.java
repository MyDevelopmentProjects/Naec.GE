package ge.naec.service;

import ge.naec.dao.MenuDAO;
import ge.naec.dto.MenuDTO;
import ge.naec.model.Menu;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MenuService {

    @Autowired
    private MenuDAO menuDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<MenuDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return menuDAO.getPaginatedResultList(Menu.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(MenuDTO.class);
    }

    public List<Menu> getMenuByLang(boolean isEnglish) {
        return menuDAO.getMenuByLang(isEnglish);
    }
}
