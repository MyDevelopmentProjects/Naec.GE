package ge.naec.service;

import ge.naec.dao.GalleryDAO;
import ge.naec.dto.GalleryDTO;
import ge.naec.model.Gallery;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class GalleryService {

    @Autowired
    private GalleryDAO galleryDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<GalleryDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize, boolean isGallery, boolean english) {
        return galleryDAO.getPaginatedResultList(Gallery.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize, isGallery, english).transform(GalleryDTO.class);
    }

}
