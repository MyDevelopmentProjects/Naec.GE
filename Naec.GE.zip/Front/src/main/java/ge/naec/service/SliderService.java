package ge.naec.service;

import ge.naec.dao.SliderDAO;
import ge.naec.dto.SliderDTO;
import ge.naec.model.Slider;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SliderService {

    @Autowired
    private SliderDAO sliderDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<SliderDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize, boolean english) {
        return sliderDAO.getPaginatedResultList(Slider.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize, english).transform(SliderDTO.class);
    }

}
