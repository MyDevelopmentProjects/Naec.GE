package ge.naec.service;

import ge.naec.dao.CategoriesDAO;
import ge.naec.dto.CategoriesDTO;
import ge.naec.model.Categories;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CategoriesService {

    @Autowired
    private CategoriesDAO categoriesDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize, boolean english) {
        return categoriesDAO.getPaginatedResultList(Categories.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize, english).transform(CategoriesDTO.class);
    }

}
