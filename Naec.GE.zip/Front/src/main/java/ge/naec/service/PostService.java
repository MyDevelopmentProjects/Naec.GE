package ge.naec.service;

import ge.naec.dao.PostDAO;
import ge.naec.dto.PostDTO;
import ge.naec.model.Post;
import ge.naec.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PostService {

    @Autowired
    private PostDAO postDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<PostDTO> getList(String searchExpression, String sortField, boolean isAscending,
                                                               Integer pageNumber, int pageSize, boolean hidden,
                                                               Long categoryId, boolean english) {
        return postDAO.getPaginatedResultList(Post.class, searchExpression,
                "dateCreated", false, pageNumber, pageSize, hidden, categoryId, english).transform(PostDTO.class);
    }

    public List<Post> getPostById(Long postId) {
        List<Post> listOfPosts = postDAO.getPostById(postId);
        return listOfPosts;
    }

    public List<Post> getLast10Records(boolean english) {
        return postDAO.getLast8Records(english);
    }


    public List<Post> getSpecialPosts(boolean isEnglish) {
        return postDAO.getSpecialPosts(isEnglish);
    }

    public List<Post> get6RandomNews(boolean english) {
        return postDAO.get6RandomNews(english);
    }

    public Post getTopNews(boolean english) {
        return postDAO.getTopNews(english);
    }
}
