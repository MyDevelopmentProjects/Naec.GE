package ge.naec.dto;

import ge.naec.mappedsupperclass.SuperDTO;

public class GalleryDTO extends SuperDTO {

    private Long id;
    private String name;
    private String images;
    private boolean video;
    private boolean english = false;
    /*************************************Getters & Setters***************************************************/
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getImages() {
        return images;
    }
    public void setImages(String images) {
        this.images = images;
    }
    public boolean getVideo() {
        return video;
    }
    public void setVideo(boolean video) {
        this.video = video;
    }
    public boolean getEnglish() {
        return english;
    }

    public void setEnglish(boolean english) {
        this.english = english;
    }
    /*************************************Getters & Setters***************************************************/
}
