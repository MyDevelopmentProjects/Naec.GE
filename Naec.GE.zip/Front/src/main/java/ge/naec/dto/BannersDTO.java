package ge.naec.dto;

import ge.naec.mappedsupperclass.SuperDTO;

import java.util.Date;

public class BannersDTO extends SuperDTO {

    private Long id;
    private byte position = 0;
    private String imgURL;
    private String frameURL;
    private String href;
    private String name;
    private Boolean active = false;
    private Boolean english = false;
    private Boolean bottom = false;
    private Boolean top = false;

    /*************************************Getters & Setters***************************************************/
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public byte getPosition() {
        return position;
    }

    public void setPosition(byte position) {
        this.position = position;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    public String getFrameURL() {
        return frameURL;
    }

    public void setFrameURL(String frameURL) {
        this.frameURL = frameURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public Boolean getEnglish() {
        return english;
    }

    public void setEnglish(Boolean english) {
        this.english = english;
    }

    public Boolean getBottom() {
        return bottom;
    }

    public void setBottom(Boolean bottom) {
        this.bottom = bottom;
    }

    public Boolean getTop() {
        return top;
    }

    public void setTop(Boolean top) {
        this.top = top;
    }

    /*************************************Getters & Setters***************************************************/

}
