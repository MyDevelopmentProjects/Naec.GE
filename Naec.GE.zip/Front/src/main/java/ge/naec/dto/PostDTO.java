package ge.naec.dto;

import ge.naec.mappedsupperclass.SuperDTO;

public class PostDTO extends SuperDTO {

    private Long id;
    private CategoriesDTO category;
    private String name;
    private String desc;
    private String frontDesc;
    private String image;
    private String images;
    private String video;
    private boolean active = true;
    private boolean english = false;
    private boolean special = false;
    private boolean requiresAuth = false;
    private boolean isFront = false;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CategoriesDTO getCategory() {
        return category;
    }

    public void setCategory(CategoriesDTO category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean getEnglish() {
        return english;
    }

    public void setEnglish(boolean english) {
        this.english = english;
    }

    public boolean getSpecial() {
        return special;
    }

    public void getSpecial(boolean special) {
        this.special = special;
    }

    public boolean getRequiresAuth() {
        return requiresAuth;
    }

    public void setRequiresAuth(boolean requiresAuth) {
        this.requiresAuth = requiresAuth;
    }

    public String getFrontDesc() {
        return frontDesc;
    }

    public void setFrontDesc(String frontDesc) {
        this.frontDesc = frontDesc;
    }

    public boolean getFront() {
        return isFront;
    }

    public void setFront(boolean front) {
        isFront = front;
    }
}
