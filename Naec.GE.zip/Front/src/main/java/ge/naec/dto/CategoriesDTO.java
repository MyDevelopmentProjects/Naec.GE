package ge.naec.dto;

import ge.naec.mappedsupperclass.SuperDTO;

public class CategoriesDTO extends SuperDTO {

    private Long id;
    private String name;
    private String image;
    private boolean english = false;
    private String video;
    private boolean visible = true;

    /*************************************Getters & Setters***************************************************/
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public String getVideo() {
        return video;
    }
    public void setVideo(String video) {
        this.video = video;
    }
    public boolean getEnglish() {
        return english;
    }
    public void setEnglish(boolean english) {
        this.english = english;
    }

    public boolean getVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    /*************************************Getters & Setters***************************************************/
}
