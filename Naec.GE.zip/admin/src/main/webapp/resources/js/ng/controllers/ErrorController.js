angular.module('imperio.controllers').controller('ErrorController',
    [ '$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {

        $('.error-div').append(lastError)

        $scope.back = function () {
            window.history.back();
        }

    }]);


