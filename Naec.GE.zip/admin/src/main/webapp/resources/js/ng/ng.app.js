var lastError = "";
var imperio = angular.module('imperio', [
    'ngFileUpload',
    'ngRoute',
    'ui.bootstrap',
    'imperio.controllers',
    'app.main',
    'app.navigation',
    'app.localize',
    'app.activity',
    'app.smartui'
]);

imperio.config(['$routeProvider', '$provide', function ($routeProvider, $provide) {
    $routeProvider
        .when('/', {
            redirectTo: '/index',
            templateUrl: 'default/layout'
        })
        .when('/index', {
            templateUrl: 'default/layout'
        })
        .when('/user', {
            templateUrl: 'user/layout',
            controller: 'UserController'
        })
        .when('/role', {
            templateUrl: 'role/layout',
            controller: 'RoleController'
        })
        .when('/permission', {
            templateUrl: 'permission/layout',
            controller: 'PermissionController'
        })
        .when('/rolepermission', {
            templateUrl: 'rolepermission/layout',
            controller: 'RolePermissionController'
        })
        .when('/category', {
            templateUrl: 'categories/layout',
            controller: 'CategoryController'
        })
        .when('/post', {
            templateUrl: 'post/layout',
            controller: 'PostController'
        })
        .when('/menu', {
            templateUrl: 'menu/layout',
            controller: 'MenuController'
        })
        .when('/videoGallery/:video', {
            templateUrl: 'gallery/videoLayout',
            controller: 'GalleryController'
        })
        .when('/imageGallery/:image', {
            templateUrl: 'gallery/layout',
            controller: 'GalleryController'
        })
        .when('/banner', {
            templateUrl: 'banner/layout',
            controller: 'BannerController'
        })
        .when('/fileManager', {
            templateUrl: 'upload/layout',
            controller: 'IOController'
        })
        .when('/slider', {
            templateUrl: 'slider/layout',
            controller: 'SliderController'
        })
        .when('/404', {
            templateUrl: 'error/404',
            controller: 'ErrorController'
        })
        .when('/500', {
            templateUrl: 'error/500',
            controller: 'ErrorController'
        })
        .otherwise({
            redirectTo: '/404',
            templateUrl: 'error/404'
        });
}]);

imperio.run(['$rootScope', 'settings', function ($rootScope, settings) {
    settings.currentLang = settings.languages[0]; // en
}]);

imperio.factory('cacheFactory', function ($cacheFactory) {
    return $cacheFactory;
});

