angular.module('imperio.controllers', [])
    .factory('settings', ['$rootScope', function ($rootScope) {
        return {
            languages: [
                {
                    language: 'English',
                    translation: 'English',
                    langCode: 'en',
                    flagCode: 'us'
                },
                {
                    language: 'Russian',
                    translation: 'Рускии',
                    langCode: 'ru',
                    flagCode: 'ru'
                },
                {
                    language: 'Georgian',
                    translation: 'ქართული',
                    langCode: 'ge',
                    flagCode: 'ge'
                }
            ]
        };
    }])
    .controller('imperioController', ['$scope', '$http', function ($scope, $http) {
        setTimeout(function () {
            $('.load-filler').fadeOut('slow');
        }, 1000)
    }])
    .controller('LangController', ['$scope', 'settings', 'localize', function ($scope, settings, localize) {
        $scope.languages = settings.languages;
        $scope.currentLang = settings.currentLang;
        $scope.setLang = function (lang) {
            settings.currentLang = lang;
            $scope.currentLang = lang;
            localize.setLang(lang);
        };

        // set the default language
        $scope.setLang($scope.currentLang);

    }]).controller('WidgetDemoCtrl', ['$scope', '$sce', function ($scope, $sce) {
        $scope.title = 'SmartUI Widget';
        $scope.icon = 'fa fa-user';
    }])
    .controller('ActivityDemoCtrl', ['$scope', '$http', function ($scope, $http) {

        /*setInterval(function () {
         $http.get('notification/list?isAscending=false&pageSize=6&sortField=id', {showLoader: 0}).
         success(function (data) {
         var html = '';
         for (var i = 0; i < data.results.length; i++) {
         var file = data.results[i].path;
         if (file) file = '/uploads/notifications/iMperio/' + file;
         html += '<li>\
         <span class="unread">\
         <a href="javascript:void(0);" class="msg">\
         <img src="' + file + '" alt="" class="air air-top-left margin-top-5" width="40" height="40">\
         <span class="from">John Doe <i class="icon-paperclip"></i></span>\
         <time>2 minutes ago</time>\
         <span class="subject">Msed quia non numquam eius modi tempora</span>\
         <span class="msg-body">Hello again and thanks for being a part of the newsletter. </span>\
         </a>\
         </span>\
         </li>';
         }
         $('.notification-body').html(html)
         if (html != '') $('.alert-transparent, .fa-envelope-square').hide();
         else $('.alert-transparent, .fa-envelope-square').show();
         });
         }, 10000);*/

    }]);
