angular.module('imperio.controllers').controller('CategoryController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.url = 'categories/list';
        $scope.AmfTable.openPage(0);
        $scope.init = {};

        $scope.showAddEdit = function (category) {
            $scope.category = {};
            $scope.meta = [];
            $scope.init.action = category ? 'რედაქტირება' : 'დამატება';
            if (category) {
                $scope.category = angular.copy(category);
            }
            $('#addEditDialog').modal('show');
        };

        $scope.$on('upload-finished', function (event, args) {
            if (args.data && args.data.length > 0) {
                $scope.category.image = args.data;
                $scope.save($scope.category.image);
            }
        });

        $scope.delete = function (path) {
            $http.post('upload/delete', siteId).
            success(function (data) {
                if (!data.isSuccess) {
                    return;
                }
                $scope.AmfTable.reloadData();
            });
        };

        $scope.save = function (image) {
            var category = angular.copy($scope.category);
            if (image) category.image = image;

            $http.post('categories/save', category).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $('#addEditDialog').modal('hide');
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.delete = function (objectId) {
            $http.post('categories/delete', objectId).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.AmfTable.reloadData(true);
            });
        };

    }]);