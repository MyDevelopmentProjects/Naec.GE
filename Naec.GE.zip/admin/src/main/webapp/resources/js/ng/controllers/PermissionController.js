angular.module('imperio.controllers').controller('PermissionController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.url = 'permission/list';
        $scope.AmfTable.openPage(0);
        $scope.init = {};

    }]);