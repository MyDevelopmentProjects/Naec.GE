/**
 * Created by Mikheil on 12/21/2015.
 */
angular.module('imperio.controllers').controller('RolePermissionController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.init = {};
        $scope.roleId = null;

        $scope.loadRoles = function () {
            $http.get('role/list', {cache: true}).
            success(function (data) {
                if (!data.success) {
                    $scope.showSuccessAlert("შეცდომა", "როლების ცხრილი ვერ ჩაიტვირთა", true);
                } else {
                    $scope.roles = data.results;
                }
            });
        };

        $scope.loadPermissions = function () {
            $http.get('permission/list?pageSize=100', {cache: true}).
            success(function (data) {
                if (!data.success) {
                    $scope.showSuccessAlert("შეცდომა", "უფლებათა ცხრილი ვერ ჩაიტვირთა", true);
                } else {
                    $scope.permissions = data.results;
                    $scope.copyPermissions = data.results;
                }
            });
        };

        $scope.permissionsByRoleId = function (roleId) {
            $scope.copyPermissions = angular.copy($scope.permissions);
            setTimeout(function () {
                angular.element('.roles').css({"background": "rgb(255, 255, 255)", "color": "#333"})
                angular.element("#role-" + roleId).css({"background": "#474544", "color": "#fff"});
            }, 200);
            $scope.roleId = roleId;
            $http.get('rolepermission/list?roleId=' + roleId).
            success(function (data) {
                if (data.length > 0) {
                    $scope.intersectArrays(data, roleId);
                }
            });
        };

        $scope.intersectArrays = function (data) {
            angular.forEach(data, function (object) {
                angular.forEach($scope.copyPermissions, function (childObject, index) {
                    if (object == childObject.id) {
                        $scope.copyPermissions[index].hasRole = true;
                    }
                })
            })
        };

        $scope.saveRolePermission = function () {
            var selected = [];
            angular.forEach($scope.copyPermissions, function (object) {
                if (object.hasRole) {
                    selected.push(object.id);
                }
            });

            var json = {
                "roleId": parseInt($scope.roleId),
                "permissions": selected
            };

            $http.post('rolepermission/save', JSON.stringify(json)).
            success(function (data) {

            });
        };

        $scope.initialize = function () {
            $scope.loadPermissions();
            $scope.loadRoles();
        };

        $scope.initialize();
    }]);