/**
 * Created by Mikheil on 12/21/2015.
 */
angular.module('imperio.controllers').controller('RoleController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.url = 'role/list';
        $scope.AmfTable.openPage(0);
        $scope.init = {};

        $scope.showAddEditRole = function (item) {
            $scope.init.action = item ? 'რედაქტირება' : 'დამატება';
            $scope.meta = [];
            if (item) {
                $scope.role = angular.copy(item);
                GridManager.loadMetaData($scope, $scope.role.meta);
            } else {
                $scope.role = {};
            }
            $('#addEditRole').modal('show');
        };

        $scope.saveRole = function () {
            $scope.role.meta = JSON.stringify($scope.meta);
            $http.post('role/save', angular.copy($scope.role)).
            success(function (data) {
                if (!data.success) {
                    $scope.showErrorModal("Error", "Role save canceled", true);
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $('#addEditRole').modal('hide');
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.deleteRole = function (roleId) {
            $http.post('role/delete', roleId).
            success(function (data) {
                if (!data.success) {
                    $scope.showErrorModal("Error", "Role can't be deleted", true);
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი წარმატებით წაიშალა", true);
                $scope.AmfTable.reloadData(true);
            });
        };
    }]);