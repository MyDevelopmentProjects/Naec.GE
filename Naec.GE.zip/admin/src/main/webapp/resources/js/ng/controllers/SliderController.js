angular.module('imperio.controllers').controller('SliderController',
    ['$scope', '$http', 'GridManager', '$sce', 'ModalManager', function ($scope, $http, GridManager, $sce, ModalManager) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.url = 'slider/list';
        $scope.AmfTable.openPage(0);
        $scope.init = {};
        $scope.slider = {};

        $scope.showAddEdit = function (slider) {
            $scope.slider.type = false;
            $scope.slider.position = 0;
            $scope.init.action = slider ? 'რედაქტირება' : 'დამატება';
            if (slider) {
                $scope.slider = angular.copy(slider);
                $scope.slider.type = $scope.slider.type === 1
            }
            $('#addEditDialog').modal('show');
            $scope.initVideo();
        };

        $scope.$on('upload-finished', function (event, args) {
            if (args.data && args.data.length > 0) {
                $scope.slider.path = args.data;
                $scope.save();
            }
        });

        $scope.delete = function (objectId) {
            $http.post('slider/delete', objectId).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.save = function () {
            var slider = angular.copy($scope.slider);
            if(slider.type == true) slider.type = 1;
            if(slider.type == false) slider.type = 0;
            if(!slider.url) slider.url = "";
            $http.post('slider/save', slider).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $('#addEditDialog').modal('hide');
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.trustURL = function (url) {
            return $sce.trustAsResourceUrl(url);
        };

        $scope.parseURL = function (url) {
            return you.youtube_parser(url)
        };

        $scope.initVideo = function () {
            $('#loaderDiv').show()
            setTimeout(function(){
                $('.popup-youtube').magnificPopup({
                    disableOn: 700,
                    type: 'iframe',
                    mainClass: 'mfp-fade',
                    removalDelay: 160,
                    preloader: false,
                    fixedContentPos: false
                });
                $('#loaderDiv').hide()
            }, 1500)
        }

    }]);