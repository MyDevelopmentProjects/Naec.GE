angular.module('imperio').directive('imperioUpload', function ($rootScope, upload) {
    return {
        restrict: 'A',
        scope: true,
        link: function (scope, element, attr) {
            element.bind('change', function () {
                var formData = new FormData();
                for (var file in element[0].files) {
                    formData.append('file', element[0].files[file]);
                }
                var type = $(element).data('type');
                var id = $(element).attr('value');
                var sf = $(element).attr('singleFile');
                formData.append('type', type);
                formData.append('id', id);
                upload('upload/file', formData, function (callback) {
                    if(sf){
                        callback = callback[0];
                    }
                    $rootScope.$broadcast('upload-finished', {data: callback});
                });
            });
        }
    };
});
imperio.factory('upload', function ($http) {
    return function (file, data, callback) {
        $http({
            url: file,
            method: "POST",
            data: data,
            headers: {'Content-Type': undefined}
        }).success(function (response) {
            callback(response);
        });
    };
});
