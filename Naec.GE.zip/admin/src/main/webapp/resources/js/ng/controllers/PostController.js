angular.module('imperio.controllers').controller('PostController',
    ['$scope', '$http', 'GridManager', 'ModalManager', '$sce', '$compile', function ($scope, $http, GridManager, ModalManager, $sce, $compile) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.url = 'post/list?pageSize=50';
        $scope.AmfTable.openPage(0);
        $scope.init = {};

        $scope.activateView = function (ele) {
            $compile(ele.contents())($scope);
            $scope.$apply();
        };

        $scope.showAddEditPost = function (post) {

            $('.summernote').destroy();

            $scope.post = {};
            $scope.meta = [];
            $scope.init.action = post ? 'რედაქტირება' : 'დამატება';
            $scope.loadCategories();

            $('.note-editable, .summernote').html('პოსტის დეტალური აღწერა...');

            if (post) {
                $scope.post = angular.copy(post);
                $('.note-editable, .summernote').html($scope.post.desc);
                if ($scope.post.images)
                    $scope.post.images = JSON.parse($scope.post.images);

                setTimeout(function () {
                    $('.dtp').datetimepicker({
                        date: moment(post.dateCreated).format("YYYY-MM-DD hh:mm"),
                        format: 'YYYY-MM-DD hh:mm'
                    });
                }, 800)

            }

            $('#addEditPostDialog').modal({
                backdrop: 'static',
                keyboard: false
            });

            $('.dropdown').dropdown();

            setTimeout(function () {
                $('.summernote').summernote({
                    focus: false,
                    tabsize: 2
                });
            }, 800);

            $scope.initVideo()
        };

        $scope.removeImage = function () {
            $scope.post.image = '';
        };

        $scope.removeSelectedImage = function (index) {
            if (confirm("წავშალო მოცემული ფოტო?") == true) {
                if (index > -1) {
                    $scope.post.images.splice(index, 1);
                }
            }
        };

        $scope.updateDate = function () {

        };

        $scope.levelUp = function (item) {
            $http.post('post/levelUp', item.id).success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.loadCategories = function () {
            $http.get('categories/dropdown', {cache: true}).success(function (data) {
                if (data.success) {
                    $scope.categories = data.results;
                }
            });
        };

        $scope.savePost = function () {

            if (!$scope.post.images) {
                $scope.post.images = undefined;
            }
            if (!$scope.post.image) {
                $scope.post.image = '';
            }

            var post = angular.copy($scope.post);

            if (post.images && post.images.length > 0)
                post.images = JSON.stringify(post.images);
            else
                post.images = undefined;

            post.desc = $('.summernote').code();

            if (post.id) {
                var dt = $('.dtp').val()
                var momDate = moment(dt)
                if (momDate.isValid()) {
                    var trimmed = dt.trim()
                    var res = trimmed.replace(" ", "T");
                    post.dateCreated = res + ":00"
                }
            }

            $http.post('post/save', post).success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $('#addEditPostDialog').modal('hide');
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.deletePost = function (objectId) {
            $http.post('post/delete', objectId).success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.$on('upload-finished', function (event, args) {
            if (args.data && args.data.length > 0) {
                if (Object.prototype.toString.call(args.data) === '[object Array]') {
                    if ($scope.post.images) {
                        $scope.post.images = $scope.post.images.concat(args.data);
                    } else {
                        $scope.post.images = args.data;
                    }
                } else {
                    $scope.post.image = args.data;
                }
            }
        });

        $scope.getPostImage = function (url, id) {
            if (url.indexOf("tn_file_") !== -1) {
                return "/uploads/postImage/" + url
            } else {
                return "/uploads/postImage/" + id + "/" + url
            }
        };

        $scope.getGalleryImage = function (url, id) {
            if (url.indexOf("tn_file_") !== -1) {
                return "/uploads/postGallery/" + url
            } else {
                return "/uploads/postGallery/" + id + "/" + url
            }
        };

        $scope.trustURL = function (url) {
            return $sce.trustAsResourceUrl(url);
        };

        $scope.parseURL = function (url) {
            return you.youtube_parser(url)
        };

        $scope.initVideo = function () {
            $('#loaderDiv').show()
            setTimeout(function () {
                $('.popup-youtube').magnificPopup({
                    disableOn: 700,
                    type: 'iframe',
                    mainClass: 'mfp-fade',
                    removalDelay: 160,
                    preloader: false,
                    fixedContentPos: false
                });
                $('#loaderDiv').hide()
            }, 1500)
        }

    }]);