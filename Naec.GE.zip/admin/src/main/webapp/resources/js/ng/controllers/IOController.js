angular.module('imperio.controllers').controller('IOController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.init = {};
        $scope.dir = "";

        $scope.dirs = [];

        $scope.baseDirSeparator = "/postData";

        $scope.backPressed = function() {
            $scope.loadDir($scope.dir != "", true)
        };

        $scope.loadDir = function (hasPrev, backPressed) {
            var param = '';
            if (hasPrev) {
                if (backPressed) {
                    var lastIndex = $scope.dir.lastIndexOf("/")
                    if (lastIndex > -1) {
                        $scope.dir = $scope.dir.substring(0, lastIndex)
                    }
                }
                $('#btnBack').show();
                param = '?dir=' + $scope.dir;
            } else {
                $('#btnBack').hide();
            }
            $http.get('upload/getDirectoryList' + param).success(function (data) {
                $scope.files = data.data;
            });
        };

        $scope.addEditDir = function (dir) {
            $scope.prevDir = angular.copy($scope.dir);
            $scope.dir = ""
            $scope.init.action = dir ? 'რედაქტირება' : 'დამატება';
            if (dir) {
                $scope.prevDir = dir;
                $scope.dir = angular.copy(dir);
            }
            $('#addEditDialog').modal('show');
        };

        $scope.save = function () {
            if ($scope.dir == "") return;
            var lastDir =  ("/" + $scope.prevDir).replace("//","/")
            var dir = lastDir + "/" + $scope.dir
            $http.post('upload/createDir', dir).success(function () {
                $scope.dir = lastDir
                $scope.loadDir(true)
                $('#addEditDialog').modal('hide');
            });
        };

        $scope.$on('upload-finished', function (event, args) {
            if (args.data && args.data.length > 0) {
                $scope.loadDir($scope.dir != "")
            }
        });

        $scope.escapeRegExp = function (str, find, replace) {
            return str.replace(new RegExp(find, 'g'), replace);
        };

        $scope.setFile = function (key, value) {

            if (key == "dir") {
                $scope.dir = value
                $scope.loadDir(true);
            } else {
                var index = value.indexOf("uploads");
                var sub = value.substr(index, value.length);
                $('.note-link-url').val(sub)
            }
        };

        $scope.openFile = function (key, value) {
            if (key != "file") {
                var lastIndex = value.lastIndexOf($scope.baseDirSeparator)
                if (lastIndex > -1) {
                    $scope.dir = value.substring(lastIndex + 9, value.length)
                    $scope.loadDir(true);
                }
            }
        };

        $scope.loadDir(false)

        $scope.deleteDir = function(item) {
            for (var i in item) {
                $http.post('upload/deleteFolder', item[i]).success(function () {
                    $scope.loadDir($scope.dir != "")
                });
                break;
            }
        };

        $scope.delete = function (item) {
            for (var i in item) {
                $http.post('upload/delete', item[i]).success(function () {
                    $scope.loadDir($scope.dir != "")
                });
                break;
            }
        }

    }
    ]);