angular.module('imperio.controllers').controller('OrganisationController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.files = [];
        $scope.defaultLocation = "41.71048856622837, 44.793486871719345";
        //$scope.AmfTable.customFilters = {'branch': true};

        $scope.loadOrganisations = function () {
            $scope.AmfTable.customFilters = undefined;
            $scope.url = 'organisation/dropdown';
            $scope.AmfTable.openPage(0);
            $scope.locales = app.getListOfLocales();
        };

        $scope.addEditOrganisation = function (item) {
            $scope.organisation = {};
            $scope.meta = [];
            $scope.resetTabBar();
            if (item) {
                $scope.organisation = angular.copy(item);
                $scope.organisation.trialLastDate = app.timeToDateShort($scope.organisation.trialLastDate);
                if ($scope.organisation.images)
                    $scope.organisation.images = JSON.parse($scope.organisation.images);
                GridManager.loadMetaData($scope, $scope.organisation.meta);
            }
            if(!$scope.organisation.location) $scope.organisation.location = $scope.defaultLocation;
            $('.organisationGrid').toggle();
            $('.organisationEditor').toggle("slide", {direction: "right"}, 400, function () {
            });

        };

        $scope.resetTabBar = function(){
            $('.nav-tabs li:first-child a').click();
        };

        $scope.googleMap = function (loc) {
            if (!loc || !(loc.indexOf(',') > -1)) loc = $scope.defaultLocation;
            var locArr = loc.split(",");
            $('#map_location').locationpicker({
                location: {
                    latitude: locArr[0],
                    longitude: locArr[1]
                },
                onchanged: function (cl, radius, isMarkerDropped) {
                    $scope.organisation.location = StringUtils.format('{0}{1}{2}',[cl.latitude,',',cl.longitude])
                }
            });
        };

        $scope.loadMAP = function () {
            $scope.googleMap($scope.organisation.location)
        };

        removeSelectedImage = function (self) {
            var index = parseInt($(self).attr('index'));
            if (index > -1) {
                $scope.organisation.images.splice(index, 1);
                $scope.saveOrganisation(true);
            }
            $scope.$apply();
        };

        $scope.initCrop = function () {
            app.initCrop('#imageCropper');
        };

        $scope.initSuperBox = function () {
            $('.superbox').SuperBox();
        };

        $scope.$on('upload-finished', function (event, args) {
            if (args.data && args.data.length > 0) {

                if ($scope.organisation.images) {
                    $scope.organisation.images = $scope.organisation.images.concat(args.data);
                } else {
                    $scope.organisation.images = args.data;
                }

                $scope.saveOrganisation(JSON.stringify($scope.organisation.images));
            }
        });

        $scope.loadOrganisations();

        $scope.saveOrganisation = function (images) {
            $scope.organisation.meta = JSON.stringify($scope.meta);
            var organisation = angular.copy($scope.organisation);
            organisation.images = images;
            $http.post('organisation/save', organisation).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $scope.AmfTable.reloadData(true);
                if (!images)
                    $scope.addEditOrganisation();
            });
        }
    }]);
