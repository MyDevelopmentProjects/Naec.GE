angular.module('imperio').directive('ngPopoverConfirm', function () {
    return {
        restirct: 'A',
        link: function (scope, element, attrs) {
            var placement = attrs['ngPopoverPlacement'] ? attrs['ngPopoverPlacement'] : 'left';
            element.popover({
                html: true,
                placement: placement,
                trigger: 'manual',
                content: "<span data-popover-confirm-container> \
		          <span class='btn btn-success popover-confirm-btn'> \
		            Confirm \
		          </span> \
		          <span class='btn btn-default popover-cancel-btn'> \
		            Cancel \
		          </span> \
		        </span>"
            });
            $(document).off('click', '[ng-popover-confirm]');
            $(document).on('click', '[ng-popover-confirm]', function () {
                var btn = $(this),
                    popover = btn.next();
                btn.popover('toggle');
            });
            $(document).off('click', '.popover-confirm-btn');
            $(document).on('click', '.popover-confirm-btn', function () {
                var popover = $(this).closest('.popover'),
                    btn = popover.prev();
                callback = btn.attr('ng-popover-confirm');
                result = eval('btn.scope().' + callback);
                btn.popover('hide');
            });
            $(document).off('click', '.popover-cancel-btn');
            $(document).on('click', '.popover-cancel-btn', function () {
                var popover = $(this).closest('.popover'),
                    btn = popover.prev();
                btn.popover('hide');
            });
        }
    };
});