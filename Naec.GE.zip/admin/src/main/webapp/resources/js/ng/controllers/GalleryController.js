angular.module('imperio.controllers').controller('GalleryController',
    ['$scope', '$http', 'GridManager', 'ModalManager', '$sce', '$routeParams', function ($scope, $http, GridManager, ModalManager, $sce, $routeParams) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.init = {};
        $scope.gallery = {};
        $scope.video = {};
        $scope.imageGallery = [];
        $scope.videoGallery = [];
        $scope.placeholder = '';
        $scope.isVideo = false;

        $scope.loadImageGallery = function () {
            $scope.isVideo = false;
            $http.get('gallery/list?isVideo=false').
            success(function (data) {
                if (data.success) {
                    $scope.imageGallery = data.results;
                }
            });
        };

        $scope.loadVideoGallery = function () {
            $scope.isVideo = true;
            $http.get('gallery/list?isVideo=true').
            success(function (data) {
                if (data.success) {
                    $scope.videoGallery = data.results;
                }
            });
        };

        $scope.removeSelectedImage = function (index) {
            if(confirm("წავშალო მოცემული ფოტო?") == true) {
                if (index > -1) {
                    $scope.gallery.images.splice(index, 1);
                    $scope.saveGallery(null, true);
                }
            }
        };

        $scope.loadPage = function () {
            if ($routeParams.video)
                $scope.loadVideoGallery()
            else
                $scope.loadImageGallery();
        };

        $scope.addEditGallery = function (gallery, isVideo) {
            $scope.gallery = {};
            $scope.gallery.video = isVideo;
            $scope.video = {};
            $scope.init.action = isVideo ? 'ვიდეოს ' : 'სურათების ';
            $scope.init.action += gallery ? 'რედაქტირება' : 'დამატება';
            $scope.placeholder = isVideo ? 'ვიდეო ბმული' : 'გალერეის დასახელება';

            if (gallery != null) {
                $scope.gallery = angular.copy(gallery);
                if ($scope.gallery.images && !isVideo)
                    $scope.gallery.images = JSON.parse($scope.gallery.images);
            }
            $scope.close();
        };

        $scope.$on('upload-finished', function (event, args) {
            if (args.data && args.data.length > 0) {
                if ($scope.gallery.images) {
                    $scope.gallery.images = $scope.gallery.images.concat(args.data);
                } else {
                    $scope.gallery.images = args.data;
                }
                $scope.saveGallery(JSON.stringify($scope.gallery.images));
            }
        });

        $scope.close = function () {
            $('.galleryGrid').toggle();
            $('.galleryEditor').toggle("slide", {direction: "right"}, 400, function () {
            });
        };

        $scope.saveGallery = function (images, doNotClose) {
            if (!$scope.gallery.images) {
                $scope.gallery.images = '';
            }
            var gallery = angular.copy($scope.gallery);

            if (images) gallery.images = images;
            else if (gallery.images && gallery.images.length > 0) gallery.images = JSON.stringify(gallery.images)

            $http.post('gallery/save', gallery).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $scope.isVideo ? $scope.loadVideoGallery() : $scope.loadImageGallery();
                if(doNotClose == false)
                    $scope.close();
            });
        };

        $scope.drawImage = function (item) {
            if (item.images.length) {
                var arr = JSON.parse(item.images);
                return "uploads/gallery/" + item.id + "/" + arr[0];
            } else {
                return 'resources/img/logo.png';
            }
        };

        $scope.delete = function (objectId) {
            $http.post('gallery/delete', objectId).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.isVideo ? $scope.loadVideoGallery() : $scope.loadImageGallery();
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი წაშლილია", true);
            });
        };

        $scope.trustURL = function (url) {
            return $sce.trustAsResourceUrl(url);
        };

        $scope.loadPage();

        $scope.parseURL = function (url) {
            return you.youtube_parser(url)
        };

        setTimeout(function () {
            $('.popup-youtube').magnificPopup({
                disableOn: 700,
                type: 'iframe',
                mainClass: 'mfp-fade',
                removalDelay: 160,
                preloader: false,
                fixedContentPos: false
            });
        }, 200)

    }]);