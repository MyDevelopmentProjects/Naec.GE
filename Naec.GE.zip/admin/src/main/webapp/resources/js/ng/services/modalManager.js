angular.module('imperio').service('ModalManager', function ($rootScope, $sce) {

    this.enableModals = function ($scope) {
        $scope.showSuccessAlert = this.showSuccessAlert;
        $scope.showErrorModal = this.showErrorModal;
        setTimeout(function () {
            $('.ui-datepicker').hide();
        }, 200);
    };

    this.showSuccessAlert = function (title, content, success, timeout) {
        $.smallBox({
            title: title,
            sound: false,
            content: "<i class='fa fa-clock-o'></i> <i>" + content + "</i>",
            color: success ? "#659265" : "#C46A69",
            iconSmall: "fa fa-check fa-2x fadeInRight animated",
            timeout: timeout ? timeout : 4000
        });
    };

    this.showErrorModal = function (title, content, success, timeout) {
        $.smallBox({
            title: title,
            sound: false,
            content: "<i class='fa fa-clock-o'></i> <i>" + content + "</i>",
            color: success ? "#659265" : "#C46A69",
            iconSmall: "fa fa-check fa-2x fadeInRight animated",
            timeout: timeout ? timeout : 4000
        });
    };

});