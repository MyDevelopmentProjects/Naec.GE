angular.module('imperio').service('GridManager', function ($http, Excel, $cacheFactory) {

    this.clearCache = function (q) {
        $cacheFactory.get('$http').remove(q);
    };

    this.givePowerTo = function ($scope, pageSize) {
        $scope.AmfTable = {};
        if (pageSize != undefined) {
            $scope.AmfTable.pageSize = pageSize;
        } else {
            $scope.AmfTable.pageSize = 10;
        }
        $scope.AmfTable.openPage = this.openPage;
        $scope.AmfTable.pageChanged = this.pageChanged;
        $scope.AmfTable.sortBy = this.sortBy;
        $scope.AmfTable.reloadData = this.reloadData;
        $scope.AmfTable.invalidateCache = this.invalidateCache;
        $scope.AmfTable.textSearch = this.textSearch;
        $scope.AmfTable.textSearchExecute = this.textSearchExecute;
        $scope.AmfTable.pageSetUp = this.pageSetUp;
        $scope.AmfTable.setSelected = this.setSelected;
        $scope.AmfTable.selected = 0;
        $scope.AmfTable.scope = $scope;
        $scope.AmfTable.exportToExcel = this.exportToExcel;
        $scope.selected = 0;
        $scope.meta = [];
    };

    this.exportToExcel = function (tableId) {
        var exportHref = Excel.tableToExcel(tableId, 'sheet name');
        setTimeout(function () {
            location.href = exportHref;
        }, 100);
    };

    this.setSelected = function ($index) {
        this.scope.selected = $index;
    };

    this.pageChanged = function (page) {
        var table = this.scope;
        table.AmfTable.openPage(page - 1);
    };

    this.openPage = function (page) {
        var table = this.scope;
        table.AmfTable.page = page;
        table.AmfTable.currentPage = page + 1;
        table.AmfTable.reloadData();
    };

    this.textSearch = function (typeTimeOut) {
        var table = this.scope;
        if (typeTimeOut == undefined) {
            typeTimeOut = 300;
        }
        table.AmfTable.lastTypeTime = (new Date()).getTime();
        var searchStr = angular.copy(table.AmfTable.searchString);
        setTimeout(function () {
            table.AmfTable.textSearchExecute(table, typeTimeOut, searchStr);
        }, typeTimeOut + 50);
    };

    this.textSearchExecute = function (table, typeTimeOut, searchString) {
        if (this.searchString != searchString) return;
        var curTime = (new Date()).getTime();
        if (curTime - table.AmfTable.lastTypeTime >= typeTimeOut) {
            table.AmfTable.page = 0;
            table.AmfTable.currentPage = 1;
            table.AmfTable.reloadData();
        }
    };

    this.sortBy = function (sortBy, sender) {
        var table = this.scope;
        if (table.AmfTable.sortColumn == sortBy) {
            table.AmfTable.sortDir = table.AmfTable.sortDir == 'asc' ? 'desc' : 'asc';
        } else {
            table.AmfTable.sortColumn = sortBy;
            table.AmfTable.sortDir = 'asc';
        }

        table.AmfTable.page = 0;
        table.AmfTable.currentPage = 1;

        table.AmfTable.reloadData();
    };

    this.pageSetUp = function () {
        pageSetUp();
    };

    this.invalidateCache = function () {
        $cacheFactory.get('$http').removeAll();
    };

    this.reloadData = function (clear) {
        var table = this.scope;
        var query = [];
        query.pageNumber = table.AmfTable.page >= 0 ? table.AmfTable.page : 0;
        query.sortField = table.AmfTable.sortColumn;
        query.isAscending = (table.AmfTable.sortDir == 'asc');
        query.searchExpression = table.AmfTable.searchString;
        query.pageSize = table.AmfTable.pageSize;
        if (table.AmfTable.customFilters != undefined) {
            var customFilters = table.AmfTable.customFilters;
            for (var key in customFilters)
                query[key] = customFilters[key];
        }
        if (clear) {
            var q = table.url;
            if (this.scope.AmfTable.customFilters != undefined) {
                var customFilters = this.scope.AmfTable.customFilters;
                q += '?';
                for (var key in customFilters)
                    q = key + '=' + customFilters[key] + '&';
            } else {
                q = q + '?';
            }
            q += 'isAscending=' + query.isAscending + '&pageNumber=' + query.pageNumber + '&pageSize=' + query.pageSize + '&sortField=' + query.sortField;
            var str = q.substr(0, q.indexOf('&sortField'));
            var cf = $cacheFactory.get('$http');
            cf.remove(q.split('?')[0]);
            cf.remove(q);
            cf.remove(str);
        }
        $http({
            url: table.url,
            method: 'GET',
            params: query
        }).success(function (data) {
            if (data.results && data.results.length == 0 && table.AmfTable.page > 0) {
                table.AmfTable.page = 0;
                table.AmfTable.reloadData();
                if (data.results && data.results.length == 0) {

                }
            } else if (data.results && data.results.length == 0) {
                table.AmfTable.page = -1;
                table.AmfTable.totalItems = 0;
                table.data = data;
            } else {
                table.data = data;
                table.AmfTable.totalItems = data.maxPages * table.AmfTable.pageSize;
                if (table.AmfTable.doOnReload != undefined) {
                    table.AmfTable.doOnReload();
                }
                if (table.AmfTable.refreshBulkActions != undefined) {
                    table.AmfTable.refreshBulkActions();
                }
            }
            table.AmfTable.currentPage = table.AmfTable.page + 1;
        });
    };

    this.loadMetaData = function ($scope, meta) {
        if (meta)
            $scope.meta = JSON.parse(meta);
    }

});