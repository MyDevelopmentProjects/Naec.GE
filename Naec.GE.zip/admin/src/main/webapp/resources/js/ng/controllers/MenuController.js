angular.module('imperio.controllers').controller('MenuController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.init = {};
        $scope.lang = "ge"

        $scope.showAddEdit = function (menu) {
            $scope.menu = {};
            $scope.init.action = menu ? 'რედაქტირება' : 'დამატება';
            if (menu) {
                $scope.menu = angular.copy(menu);
            }
            $('#addEditDialog').modal('show');
            if(menu) {
                $scope.$apply()
                $scope.$digest()
            }
        };

        $scope.save = function () {
            var menu = angular.copy($scope.menu);
            $http.post('menu/save', menu).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.AmfTable.invalidateCache();
                $scope.getMenuByLang();
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $('#addEditDialog').modal('hide');
            });
        };

        $scope.changeLang = function () {
            if ($scope.lang == "ge") {
                $('.langChooser').removeClass('flag-ge').addClass('flag-england')
                $scope.lang = "en"
            }
            else {
                $scope.lang = "ge"
                $('.langChooser').removeClass('flag-england').addClass('flag-ge')
            }
            $scope.getMenuByLang();
        };

        $scope.delete = function (objectId) {
            $http.post('menu/delete', objectId).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.AmfTable.invalidateCache();
                $scope.getMenuByLang();
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი წაშლილია", true);
            });
        };

        $scope.compare = function (a,b) {
            if (a.parentId < b.parentId)
                return -1;
            if (a.parentId > b.parentId)
                return 1;
            return 0;
        };

        $scope.getMenuByLang = function () {
            $http.get('menu/getByLang?lang=' + $scope.lang, {cache: true}).success(function (data) {
                $('#menu-container').html('').append('<ul id="menu"></ul>')
                data.sort($scope.compare);
                var source = $scope.buildSource(data);
                $('#menu').html('')
                $scope.buildUL($('#menu'), source);
                $('#menu-container').easytree();
            });
        };

        $scope.buildSource = function (data) {
            var source = [];
            var items = [];
            for (var i = 0; i < data.length; i++) {
                var item = data[i];
                var label = item["name"];
                var url = item["href"];
                var parentId = item["parentId"];
                var id = item["id"];
                var isEnglish = item["english"];

                if (items[parentId]) {
                    var item = {id: id, parentId: parentId, label: label, url: url, item: item, isEnglish: isEnglish};
                    if (!items[parentId].items) {
                        items[parentId].items = [];
                    }
                    items[parentId].items[items[parentId].items.length] = item;
                    items[id] = item;
                }
                else {
                    items[id] = {id: id, parentId: parentId, label: label, url: url, item: item};
                    source[id] = items[id];
                }
            }
            return source;
        };

        $scope.buildUL = function (parent, items) {
            $.each(items, function () {
                if (this.label) {
                    var li = $("<li _id='" + this.id + "'  parentId='" + this.parentId + "' href='" + this.item.href + "'>" + this.label + "</li>");
                    if (this.items && this.items.length > 0) {
                        li = $("<li _id='" + this.id + "'  parentId='" + this.parentId + "' href='" + this.item.href + "'>" + this.label + "</li>");
                    }
                    if(!this.item.active)
                        li.addClass('inActive')
                    li.appendTo(parent);
                    if (this.items && this.items.length > 0) {
                        li.addClass('isFolder');
                        var ul = $("<ul></ul>");
                        ul.appendTo(li);
                        $scope.buildUL(ul, this.items);
                    }
                }
            });
        };

        $scope.getMenuByLang();

        $scope.setHref = function (uri, id) {
            $scope.menu.href = uri + id;
        };

        $(document).ready(function () {
            $(document).on("click", ".ui-easytree .actions i", function (event) {

                event.preventDefault()

                var target = $(event.target);

                var type = target.attr('type')

                var node = target.parent().prev()

                var parentNode = node.parent()

                var objId = parseInt(parentNode.attr('_id'))

                if (type == "edit") {

                    $scope.menu = {
                        id: objId,
                        parentId: parentNode.attr('parentid') != "null" ? parseInt(parentNode.attr('parentid')) : null,
                        name: node.find('.easytree-title').text(),
                        href: parentNode.attr('href'),
                        english: $scope.lang != "ge",
                        active: node.find('.inActive').length == 0
                    };

                    $scope.showAddEdit($scope.menu)

                } else if (type == "add") {

                    $scope.menu = {
                        parentId: objId ? objId : null,
                        name: $scope.lang == "ge" ? "ახალი მენუ ღილაკი" : "New menu item",
                        href: "#",
                        english: $scope.lang != "ge",
                        active: true
                    };

                    $scope.showAddEdit($scope.menu)

                } else if (type == "remove") {

                    if (confirm("ნამდვილად გსურთ წაშალოთ ჩანაწერი? მოცემული ჩანაწერის აღდგენა ვეღარ მოხდება")) {
                        $scope.delete(objId)
                    } else {
                        return false;
                    }

                }

            });

            document.addEventListener("MenuItemDropped",function(ev){

                var data = ev.customData;
                var source = data[0];
                var target = data[1];

                $scope.menu = {
                    id: source._id,
                    parentId: target._id,
                    name: source.text,
                    href: source.uri,
                    english: $scope.lang != "ge",
                    active: source.inActive == false
                };

                console.log($scope.menu)

                $scope.save();


            },false);

        });



    }]);