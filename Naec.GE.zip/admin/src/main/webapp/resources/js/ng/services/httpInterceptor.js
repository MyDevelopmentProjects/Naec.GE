angular.module('imperio').factory('httpInterceptor', function ($q, $rootScope, ModalManager) {
        var numLoadings = 0;
        return {
            request: function (config) {
                numLoadings++;
                if (config.showLoader != 0) $rootScope.$broadcast("loader_show");
                return config || $q.when(config);
            },
            response: function (response) {
                errorUtils.handle_error(response.data, ModalManager);
                if ((--numLoadings) === 0) {
                    $rootScope.$broadcast("loader_hide");
                }
                return response || $q.when(response);
            },
            responseError: function (response) {
                if (!(--numLoadings)) {
                    $rootScope.$broadcast("loader_hide");
                }
                ModalManager.showErrorModal(
                    'Server is experiencing difficulties, please contact your administrator if the condition persists! URL: \''
                    + response.config.url, response.data, response.status);
                return $q.reject(response);
            }
        };
    })
    .config(function ($httpProvider) {
        $httpProvider.interceptors.push('httpInterceptor');
    });