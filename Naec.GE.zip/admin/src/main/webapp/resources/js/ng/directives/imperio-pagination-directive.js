angular.module('imperio').directive('imperioPager', function () {
    return {
        restrict: 'E',
        templateUrl: 'resources/includes/pagination.jsp'
    };
});