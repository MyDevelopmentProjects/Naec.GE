angular.module('imperio').directive('imperioSearchInput', function () {
    return {
        restrict: 'E',
        templateUrl: 'resources/includes/imperio-search.jsp'
    };
});