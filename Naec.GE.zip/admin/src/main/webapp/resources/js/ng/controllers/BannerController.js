angular.module('imperio.controllers').controller('BannerController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);

        $scope.url = 'banner/list';
        $scope.AmfTable.openPage(0);
        $scope.init = {};

        $scope.showAddEdit = function (item) {
            $scope.object = {};
            $scope.meta = [];
            $scope.init.action = item ? 'რედაქტირება' : 'დამატება';
            if (item) {
                $scope.object = angular.copy(item);
                GridManager.loadMetaData($scope, $scope.object.meta);
            }
            $('#addEditDialog').modal('show');
        };

        $scope.save = function (imgURL) {
            var objClone = angular.copy($scope.object);
            if(imgURL) objClone.imgURL = imgURL;
            objClone.meta = JSON.stringify($scope.meta);
            $http.post('banner/save', objClone).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                if(!imgURL)$('#addEditDialog').modal('hide');
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.delete = function (objectId) {
            $http.post('banner/delete', objectId).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.$on('upload-finished', function (event, args) {
            if (args.data && args.data.length > 0) {
                $scope.object.imgURL = args.data[0];
                $scope.save($scope.object.imgURL);
            }
        });
    }]);
