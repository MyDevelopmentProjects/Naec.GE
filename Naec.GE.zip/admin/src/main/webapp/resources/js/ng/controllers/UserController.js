angular.module('imperio.controllers').controller('UserController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {
        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.url = 'user/list';
        $scope.AmfTable.openPage(0);
        $scope.init = {};

        $scope.showAddEditUser = function (user) {
            $scope.user = {};
            $scope.meta = [];
            $scope.loadRoles();
            $scope.init.action = user ? 'რედაქტირება' : 'დამატება';
            if (user) {
                $scope.user = angular.copy(user);
                $scope.user.dob = app.timeToDateShort($scope.user.dob);
                GridManager.loadMetaData($scope, $scope.user.meta);
            }
            $('#addEditUserDialog').modal('show');
            $('.dropdown').dropdown();
        };

        $scope.loadRoles = function () {
            $http.get('role/list', {cache: true}).
            success(function (data) {
                if (!data.success) {
                    $('#addEditUserDialog').modal('show');
                } else {
                    $scope.roles = data.results;
                }
            });
        };

        $scope.saveUser = function () {
            $scope.user.meta = JSON.stringify($scope.meta);
            $http.post('user/save', $scope.user).
            success(function (data) {
                if (!data.success) {
                    if (data.errorMessage == "DUPLICATE_RECORD") {
                        $scope.showSuccessAlert("შეცდომა", "მომხმარებელი ასეთი სახელით უკვე არსებობს", false);
                    } else {
                        $scope.showSuccessAlert("შეცდომა", "მოხდა შეცდომა, სცადეთ მოგვიანებით", false);
                    }
                    return;
                }
                $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", "ჩანაწერი შენახულია", true);
                $scope.AmfTable.reloadData(true);
                $('#addEditUserDialog').modal('hide');
            });
        };

        $scope.deleteUser = function (userId) {
            $http.post('user/delete', userId).
            success(function (data) {
                if (!data.success) {
                    return;
                }
                $scope.AmfTable.reloadData(true);
            });
        };

    }]);
