angular.module('imperio').directive('imperioDateCud', function () {
    return {
        restrict: 'E',
        templateUrl: 'resources/includes/date-cud.jsp',
        replace: true,
        scope: {
            ngModel: '='
        }
    };
});