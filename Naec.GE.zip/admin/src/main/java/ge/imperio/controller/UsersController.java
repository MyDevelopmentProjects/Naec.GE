package ge.imperio.controller;

import ge.imperio.dto.UsersDTO;
import ge.imperio.model.Users;
import ge.imperio.service.UsersService;
import ge.imperio.utils.RequestResponse;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.imperio.utils.constants.Constants.CustomCodeConstants.*;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.Keys.*;

@Controller
@RequestMapping("/user")
public class UsersController {

    @Autowired
    private UsersService usersService;

    @PreAuthorize("hasAuthority('SHOW_USER')")
    @RequestMapping("/layout")
    public String getTemplate() {
        return "user/user";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('USER_LIST')")
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UsersDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return usersService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);

    }

    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('USER_SAVE')")
    @ResponseBody
    public RequestResponse saveUser(@RequestBody Users user) {
        usersService.saveUser(user);
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('USER_DELETE')")
    @ResponseBody
    public RequestResponse deleteUser(@RequestBody Long id) {
        usersService.deleteUser(id);
        return RequestResponse.SUCCESS();
    }
}
