package ge.imperio.controller;

import ge.imperio.utils.MGLUserUtils;
import ge.imperio.utils.constants.Constants;
import ge.imperio.utils.email.MGLMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.File;

@Controller
@RequestMapping("/default")
public class DefaultController {
    @RequestMapping("/layout")
    public String getTemplate() {
        return "default/default";
    }
}
