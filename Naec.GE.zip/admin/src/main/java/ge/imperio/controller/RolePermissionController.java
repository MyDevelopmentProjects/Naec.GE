package ge.imperio.controller;

import ge.imperio.dto.RolesDTO;
import ge.imperio.model.Roles;
import ge.imperio.service.RolesService;
import ge.imperio.utils.RequestResponse;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static ge.imperio.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/rolepermission")
public class RolePermissionController {

    @Autowired
    private RolesService rolesService;

    @RequestMapping(SLASH + LAYOUT)
    public String getTemplate() {
        return "role/rolepermission";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('SHOW_ROLE_PERM')")
    @ResponseBody
    public List getList(@RequestParam(required = true, defaultValue = "0") long roleId) {
        return rolesService.getRolePermissions(roleId);
    }

    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('ROLE_PERM_SAVE')")
    @ResponseBody
    public RequestResponse saveRole(@RequestBody String json) {
        rolesService.saveRolePermission(json);
        return RequestResponse.SUCCESS();
    }

}
