package ge.imperio.controller;

import ge.imperio.dto.BannersDTO;
import ge.imperio.model.Banners;
import ge.imperio.service.BannersService;
import ge.imperio.utils.RequestResponse;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.imperio.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/banner")
public class BannersController {

    @Autowired
    private BannersService bannersService;

    @RequestMapping("/layout")
    public String getTemplate() {
        return "banner/banner";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('BANNER_LIST')")
    @ResponseBody
    public PaginationAndFullSearchQueryResult<BannersDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return bannersService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);

    }

    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('BANNER_SAVE')")
    @ResponseBody
    public RequestResponse saveBanner(@RequestBody Banners banner) {
        bannersService.saveBanner(banner);
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('BANNER_DELETE')")
    @ResponseBody
    public RequestResponse deleteBanner(@RequestBody Long id) {
        bannersService.deleteBanner(id);
        return RequestResponse.SUCCESS();
    }
}
