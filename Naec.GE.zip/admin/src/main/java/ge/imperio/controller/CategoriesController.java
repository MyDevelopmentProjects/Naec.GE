package ge.imperio.controller;

import ge.imperio.dto.CategoriesDTO;
import ge.imperio.model.Categories;
import ge.imperio.service.CategoriesService;
import ge.imperio.utils.RequestResponse;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.imperio.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/categories")
public class CategoriesController {

    @Autowired
    private CategoriesService categoriesService;

    @RequestMapping("/layout")
    public String getTemplate() {
        return "category/category";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('CAT_LIST')")
    @ResponseBody
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return categoriesService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);

    }

    @RequestMapping(value = "/dropdown", method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('CAT_LIST')")
    @ResponseBody
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList() {
        return categoriesService.getList();
    }

    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('CAT_SAVE')")
    @ResponseBody
    public RequestResponse saveService(@RequestBody Categories service) {
        categoriesService.saveService(service);
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('CAT_DELETE')")
    @ResponseBody
    public RequestResponse deleteService(@RequestBody Long id) {
        categoriesService.deleteService(id);
        return RequestResponse.SUCCESS();
    }
}
