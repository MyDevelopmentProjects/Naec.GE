package ge.imperio.controller;

import ge.imperio.dto.RolesDTO;
import ge.imperio.model.Roles;
import ge.imperio.service.RolesService;
import ge.imperio.utils.RequestResponse;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.imperio.utils.constants.Constants.CustomCodeConstants.*;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.Keys.*;

@Controller
@RequestMapping("/role")
public class RolesController {

    @Autowired
    private RolesService rolesService;

    @RequestMapping(SLASH + LAYOUT)
    public String getTemplate() {
        return "role/role";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('ROLES_LIST')")
    @ResponseBody
    public PaginationAndFullSearchQueryResult<RolesDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return rolesService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('ROLES_SAVE')")
    @ResponseBody
    public RequestResponse saveRole(@RequestBody Roles role) {
        rolesService.saveRole(role);
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('ROLES_DELETE')")
    @ResponseBody
    public RequestResponse deleteRole(@RequestBody Long id) {
        rolesService.deleteRole(id);
        return RequestResponse.SUCCESS();
    }
}
