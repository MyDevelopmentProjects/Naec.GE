package ge.imperio.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import ge.imperio.utils.constants.Constants.*;

@Controller
public class LoginController {

    @RequestMapping(value = {"/"}, method = RequestMethod.GET)
    public ModelAndView welcomePage() {
        ModelAndView model = new ModelAndView();
        model.addObject("title", "Spring Security Custom Login Form");
        model.addObject("message", "This is welcome page!");
        model.setViewName("index");
        return model;
    }

    @RequestMapping("/kxgjthrf.htm")
    public String getTemplate() {
        return "kxgjthrf";
    }

    @RequestMapping("/forgotpwd")
    public String forgotPwd() {
        return "forgotpassword";
    }

    @RequestMapping("/register")
    public String register() {
        return "register";
    }

    @RequestMapping(value = CustomCodeConstants.SLASH + CustomCodeConstants.LOGIN, method = RequestMethod.GET)
    public ModelAndView login(String error, String logout) {
        ModelAndView model = new ModelAndView();
        if (error != null) {
            model.addObject(CustomCodeConstants.ERROR, ErrorCodes.INVALID_USERNAME_OR_PASSWORD);
        }
        if (logout != null) {
            model.addObject(CustomCodeConstants.MSG, SuccessMessages.LOGGED_OUT_SUCCESSFULLY);
        }
        model.setViewName(CustomCodeConstants.LOGIN);
        return model;
    }
}
