package ge.imperio.controller;

import ge.imperio.utils.*;
import ge.imperio.utils.constants.Constants;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;

@Controller
@RequestMapping("/upload")
public class UploadController {

    private static String slash = "\\\\";

    @RequestMapping("/layout")
    public String getTemplate() {
        return "files/files";
    }

    @RequestMapping(value = "/file", method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('UPLOAD_FILE')")
    @ResponseBody
    public List<String> uploadMultipleFileHandler(@RequestParam("file") MultipartFile[] files,
                                                  @RequestParam("type") String type,
                                                  @RequestParam("id") String objectId
    ) {
        if (files == null || files.length == 0 ||
                MGLStringUtils.IsNullOrBlank(type)) return null;
        if (!MGLIOUtils.limitFileSize(files)) return null;
        if (!MGLIOUtils.isValidObjectPath(type)) return null;

        objectId = objectId.replaceAll(slash, "/");
        if (objectId.endsWith("/") || objectId.endsWith("\\")) {
            objectId = objectId.substring(0, objectId.length() - 1);
        }

        return MGLUploadHelper.uploadFiles(files, type, objectId);
    }

    @RequestMapping(value = "/getDirectoryList", method = RequestMethod.GET)
    @ResponseBody
    public HashMap<String, Object> getDirectoryList(@RequestParam(required = false) String dir) {
        if (dir != null) {
            if (!dir.contains(Constants.UploadHelpers.POST_FILE))
                dir = String.format("%s%s", Constants.UploadHelpers.POST_FILE, dir);
            dir = dir.replaceAll(slash, "/");
        }
        return MGLIOUtils.getDirectoryList(dir);
    }

    @RequestMapping(value = "/getFileContent", method = RequestMethod.GET)
    @ResponseBody
    public String getFileContent(@RequestParam(required = false) String path) throws IOException {
        return MGLIOUtils.readFile(path, StandardCharsets.UTF_8);
    }


    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public Boolean deleteFile(@RequestBody String path) throws IOException {
        if (!path.contains(Constants.UploadHelpers.POST_FILE)) return false;
        return MGLIOUtils.deleteFile(path);
    }

    @RequestMapping(value = "/deleteFolder", method = RequestMethod.POST)
    @ResponseBody
    public Boolean deleteFolder(@RequestBody String path) throws IOException {
        if (!path.contains(Constants.UploadHelpers.POST_FILE)) return false;
        return MGLIOUtils.deleteDirectory(path);
    }

    @RequestMapping(value = "/createDir", method = RequestMethod.POST)
    @ResponseBody
    public HashMap createDir(@RequestBody String path) throws IOException {
        if (!path.contains(Constants.UploadHelpers.POST_FILE))
            path = String.format("%s%s", Constants.UploadHelpers.POST_FILE, path);
        path = path.replaceAll(slash, "/");

        if (path.endsWith("/") || path.endsWith("\\")) {
            path = path.substring(0, path.length() - 1);
        }

        HashMap<String, String> dir = new HashMap<>(1);
        dir.put("dir", MGLIOUtils.checkDirs(path));
        return dir;
    }

}
