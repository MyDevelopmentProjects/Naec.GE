package ge.imperio.controller;

import ge.imperio.model.Menu;
import ge.imperio.model.Post;
import ge.imperio.service.MenuService;
import ge.imperio.utils.MGLMainUtils;
import ge.imperio.utils.RequestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static ge.imperio.utils.constants.Constants.CustomCodeConstants.Keys.DELETE;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.Keys.SAVE;
import static ge.imperio.utils.constants.Constants.CustomCodeConstants.SLASH;

@Controller
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;

    @RequestMapping("/layout")
    public String getTemplate() {
        return "menu/menu";
    }

    @RequestMapping(value = "/getByLang")
    @ResponseBody
    public List<Menu> getMenuByLang(@RequestParam(required = false, defaultValue = "ge") String lang) {
        return menuService.getMenuByLang(MGLMainUtils.isEnglish(lang));
    }

    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('MENU_SAVE')")
    @ResponseBody
    public RequestResponse save(@RequestBody Menu menu) {
        menuService.save(menu);
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('MENU_DELETE')")
    @ResponseBody
    public RequestResponse delete(@RequestBody Long id) {
        menuService.delete(id);
        return RequestResponse.SUCCESS();
    }

}
