package ge.imperio.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by Butqucha on 10/16/15.
 */
@Controller
@RequestMapping("/error")
public class ErrorsController {
    @RequestMapping("/404")
    public String goTo404() {
        return "error/error404";
    }

    @RequestMapping("/500")
    public String goTo500() {
        return "error/error500";
    }
}
