package ge.imperio.utils.email;

import ge.imperio.utils.MGLStringUtils;
import java.io.File;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MGLMailSender {

    private MailConfig mailConfig;
    private static final String PORT = "25";
    private static final String HOST = "mgldev.ge";

    private MGLMailSender() {
        initConfig();
    }

    private void initConfig() {
        this.mailConfig = new MailConfig();
    }

    private Properties initProperties() {
        Properties mailProperties = new Properties();
        mailProperties.put("mail.smtp.auth", "true");
        mailProperties.put("mail.smtp.host", HOST);
        mailProperties.put("mail.smtp.port", PORT);
        return mailProperties;
    }

    private Session initSession(Properties props) {
        return Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(mailConfig.getUsername(), mailConfig.getPassword());
                    }
                });
    }

    public static void sendEmail(String[] recipients, String body, String subject, String filePath) {
        MGLMailSender javaMail = new MGLMailSender();
        if (javaMail.mailConfig == null) return;
        String from = javaMail.mailConfig.getUsername();
        Properties props = javaMail.initProperties();
        Session session = javaMail.initSession(props);

        try {
            // Create a default MimeMessage object.
            Message message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            Address[] toAddresses = new Address[recipients.length];
            for (int i = 0; i < recipients.length; i++) {
                toAddresses[i] = new InternetAddress(recipients[i]);
            }

            // Set To: header field of the header.
            message.setRecipients(Message.RecipientType.TO, toAddresses);

            // Set Subject: header field
            message.setSubject(subject);

            // Create the message part
            BodyPart messageBodyPart = new MimeBodyPart();

            // Now set the actual message
            messageBodyPart.setText(body);

            // Create a multipar message
            Multipart multipart = new MimeMultipart();

            // Set text message part
            multipart.addBodyPart(messageBodyPart);

            // Part two is attachment
            if (!MGLStringUtils.IsNullOrBlank(filePath)) {
                File file = new File(filePath);
                if (file.exists()) {
                    messageBodyPart = new MimeBodyPart();
                    DataSource source = new FileDataSource(filePath);
                    messageBodyPart.setDataHandler(new DataHandler(source));
                    messageBodyPart.setFileName(filePath);
                    multipart.addBodyPart(messageBodyPart);
                    // Send the complete message parts
                }
            }
            message.setContent(multipart);
            // Send message
            Transport.send(message);
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }

}