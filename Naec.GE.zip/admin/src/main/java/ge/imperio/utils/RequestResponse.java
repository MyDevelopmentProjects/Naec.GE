package ge.imperio.utils;

public class RequestResponse {

    private Boolean success;

    private String errorMessage;

    private String exceptionMessage;

    private Integer code;

    public RequestResponse() {
    }

    public static RequestResponse SUCCESS() {
        return new RequestResponse(true);
    }

    public static RequestResponse ERROR() {
        return new RequestResponse(false);
    }

    public static RequestResponse createErrorResponse(String errorMessage, String exceptionMessage, int code) {
        RequestResponse result = new RequestResponse(false);

        result.setErrorMessage(errorMessage);
        result.setExceptionMessage(exceptionMessage);
        result.setCode(code);
        return result;
    }

    public static RequestResponse createErrorResponseWithCode(Integer errorCode) {
        RequestResponse result = new RequestResponse(false);
        result.setSuccess(false);
        result.setCode(errorCode);
        return result;
    }

    public RequestResponse(Boolean success) {
        this.success = success;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getExceptionMessage() {
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

}