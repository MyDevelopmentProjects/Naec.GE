package ge.imperio.utils.constants;

import ge.imperio.config.AppConfig;

import java.io.File;

public class Constants {

    public static final String[] VALID_EXTENSIONS = {"png", "jpg", "pdf", "xls", "xlsx", "doc", "docx"};
    public static final String[] VALID_OBJECT_NAMES = {"GALLERY", "SLIDER", "CATEGORY", "POST_GALLERY", "BANNERS", "RAR", "ZIP", "XLS", "DOC", "PDF", "POST_FILE", "POST_IMAGE"};

    public static final class UploadHelpers {
        private static final String HOME = String.format("%s%s", System.getProperty("user.home"), File.separator);
        private static final String UPLOADS = AppConfig.IS_DEBUG_MODE ? String.format("%s%s%s", HOME, "uploads", File.separator) : "/opt/tomcat/uploads/";
        public static final String BANNERS = String.format("%s%s", UPLOADS, "banners");
        public static final String POST_GALLERY = String.format("%s%s", UPLOADS, "postGallery");
        public static final String POST_FILE = String.format("%s%s", UPLOADS, "postData");
        public static final String POST_IMAGE = String.format("%s%s", UPLOADS, "postImage");
        public static final String GALLERY = String.format("%s%s", UPLOADS, "gallery");
        public static final String SLIDER = String.format("%s%s", UPLOADS, "slider");
        public static final String CATEGORY = String.format("%s%s", UPLOADS, "category");
        public static final String PDF = String.format("%s%s%s%s", UPLOADS, "postData", File.separator, "pdf");
        public static final String DOC = String.format("%s%s%s%s", UPLOADS, "postData", File.separator, "doc");
        public static final String XLS = String.format("%s%s%s%s", UPLOADS, "postData", File.separator, "xls");
        public static final String RAR = String.format("%s%s%s%s", UPLOADS, "postData", File.separator, "rar");
        public static final String ZIP = String.format("%s%s%s%s", UPLOADS, "postData", File.separator, "zip");
    }

    /**
     * Error Code Constants.
     * Starting from 1000 till 2000
     */
    public static final class ErrorCodes {
        public static final int INVALID_USERNAME_OR_PASSWORD = 1000;
        public static final int YOU_DO_NOT_HAVE_PERMISSION_TO_PERFORM_THIS_ACTION = 1001;

        public class ErrorResponse {
            public static final String ACCESS_IS_DENIED = "access_is_denied";
            public static final String UNKNOWN = "unknown";
            public static final String DUPLICATE_RECORD = "DUPLICATE_RECORD";
            public static final String RECORD_IS_USED_IN_OTHER_TABLES = "RECORD_IS_USED_IN_OTHER_TABLES";
            public static final String PERSISTENCE_EXCEPTION = "javax.persistence.PersistenceException";
            public static final String NO_ENOUGH_MONEY = "NO_ENOUGH_MONEY";
            public static final String SALARY_IS_ALREADY_CREATED_FOR_TODAY = "SALARY_IS_ALREADY_CREATED_FOR_TODAY";
        }

        public class ErrorMessages {
            public static final String TRIAL_DATE_HAS_BEEN_EXPIRED = "საცდელი ვადა გასულია. დაუკავშირდით ადმინისტრაციას";
            public static final String INCORRECT_CREDS = "არასწორი მომხმარებელი ან პაროლი";
            public static final String USER_NOT_FOUND = "მომხმარებელი ვერ მოიძებნა";
        }

    }

    /**
     * SuccessMessages Code Constants.
     * Starting from 2000 till 3000
     */
    public static final class SuccessMessages {
        public static final int LOGGED_OUT_SUCCESSFULLY = 3000;
        public static final int OPERATION_COMPLETED_SUCCESSFULLY = 3001;
    }

    /**
     * CustomCodeConstants code Constants
     * This class contains all the string constants, needed in the classes while coding something
     */
    public static final class CustomCodeConstants {

        public static final String ERROR = "error";
        public static final String LOGOUT = "logout";
        public static final String LOGIN = "login";
        public static final String REDIRECT_TO_MAIN = "redirect:/";
        public static final String INDEX = "index";
        public static final String SLASH = "/";
        public static final String MSG = "msg";
        public static final String SUCCESS = "success";
        public static final String CODE = "code";
        public static final String SOURCE = "source";
        public static final String MESSAGE = "message";
        public static final String RESOURCES_ALL = "/resources/**";
        public static final String STRING_EMPTY = "";
        public static final String UNKNOWN_ERROR = "Something went wrong!";
        public static final String SITE_ID = "siteId";


        public static class Keys {

            public static final String PAGE_NUMBER = "pageNumber";
            public static final String PAGE_NUMBER_DEFAULT_VALUE = "0";
            public static final String PAGE_SIZE_DEFAULT_VALUE = "10";
            public static final String IS_ASCENDING_DEFAULT_VALUE = "true";
            public static final String LIST = "list";
            public static final String APP = "application";
            public static final String LAYOUT = "layout";
            public static final String SAVE = "save";
            public static final String DELETE = "delete";
            public static final String ROLE_ID = "RoleId";
            public static final String PERMISSIONS = "Permissions";
            public static final String KEY = "key";
            public static final String VALUE = "value";


        }
    }


}
