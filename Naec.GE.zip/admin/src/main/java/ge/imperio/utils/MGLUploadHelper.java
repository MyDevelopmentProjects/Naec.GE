package ge.imperio.utils;

import org.springframework.web.multipart.MultipartFile;

import javax.swing.filechooser.FileSystemView;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import static ge.imperio.utils.constants.Constants.UploadHelpers.*;

/**
 * Created by Butqucha on 10/26/15.
 */
public class MGLUploadHelper {

    public static List<String> uploadFiles(MultipartFile[] files, String objectName, String objectId) {
        List<String> fileNames = new ArrayList<>(files.length);
        for (int i = 0; i < files.length; i++) {
            String uploadPath = getPath(objectName);
            objectId = objectId.replace(uploadPath, "");
            MultipartFile file = files[i];
            try {
                byte[] bytes = file.getBytes();
                if (!objectName.equals("BANNERS")) {
                    if (!MGLStringUtils.IsNullOrBlank(objectId)) {
                        uploadPath = String.format("%s%s%s", uploadPath,
                                File.separator, objectId);
                    }
                }
                String ap = MGLIOUtils.checkDirs(uploadPath);

                String originalName = file.getOriginalFilename();

                if (MGLStringUtils.IsNullOrBlank(objectId)) {
                    originalName = "tn_file_" + originalName;
                }

                String serverFileName = String.format("%s%s%s", ap, File.separator, originalName);
                File serverFile = new File(serverFileName);
                BufferedOutputStream stream = new BufferedOutputStream(
                        new FileOutputStream(serverFile));
                stream.write(bytes);
                stream.close();
                fileNames.add(originalName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return fileNames;
    }

    private static String getPath(String path) {
        switch (path) {
            case "GALLERY":
                return GALLERY;
            case "RAR":
                return RAR;
            case "ZIP":
                return ZIP;
            case "XLS":
                return XLS;
            case "DOC":
                return DOC;
            case "PDF":
                return PDF;
            case "POST_FILE":
                return POST_FILE;
            case "POST_IMAGE":
                return POST_IMAGE;
            case "BANNERS":
                return BANNERS;
            case "CATEGORY":
                return CATEGORY;
            case "SLIDER":
                return SLIDER;
            default:
                return POST_GALLERY;
        }
    }

}
