package ge.imperio.utils;

import ge.imperio.model.Permissions;
import ge.imperio.model.Users;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MGLUserUtils {

    private static Authentication getCurrentLoggedInUser() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    public static Users getCurrentUser() {
        return (Users) getCurrentLoggedInUser().getPrincipal();
    }

    public static List<Permissions> getListOfPermissions() {
        return getCurrentUser().getRole().getPermissions();
    }

    public static boolean hasAuthority(String perm) {
        List<Permissions> permissions = getListOfPermissions();
        if (permissions == null) return false;
        for (Permissions prm : permissions)
            if (prm.getName().equals(perm))
                return true;
        return false;
    }
}
