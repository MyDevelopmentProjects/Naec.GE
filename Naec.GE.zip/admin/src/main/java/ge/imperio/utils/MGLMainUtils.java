package ge.imperio.utils;

import ge.imperio.utils.constants.Constants;

import java.util.Arrays;
import java.util.Random;

/**
 * Created by TuraMan on 5/14/2015.
 */
public class MGLMainUtils {

    public static String generateString(int length) {
        if (length < 5) length = 5;
        String chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Random rng = new Random();
        char[] text = new char[length];
        for (int i = 0; i < length; i++) {
            text[i] = chars.charAt(rng.nextInt(chars.length()));
        }
        return String.valueOf(text);
    }

    public static boolean isEnglish(String lang){
        return lang != null && lang.equals("en");
    }

    public static String MD5(String md5) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] array = md.digest(md5.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
        }
        return null;
    }

    public static void sendEmail(String email, String text) {

    }

    public static class ReportingTools {

        public static final String[] TRANSACTION_STATUS = {"დაიწყო", "დასრულდა", "გაუთვალისწინებელი ხარჯი"};
        public static final String[] PAYMENT_TYPES = {"ყიდვა ბალანსიდან", "შეძენა/გამოყენება აბონიმენტი", "ქეში", "ვიზა", "სალარო"};
        public static final String[] TRANSACTION_TYPES = {"შემავალი", "გამავალი"};

    }
}
