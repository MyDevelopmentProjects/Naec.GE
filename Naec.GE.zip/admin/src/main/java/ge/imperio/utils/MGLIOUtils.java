package ge.imperio.utils;

import ge.imperio.utils.constants.Constants;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class MGLIOUtils {

    public static void copyFolder(File source, File destination) {
        if (source.isDirectory()) {
            if (!destination.exists()) {
                destination.mkdirs();
            }
            String files[] = source.list();
            for (String file : files) {
                File srcFile = new File(source, file);
                File destFile = new File(destination, file);
                copyFolder(srcFile, destFile);
            }
        } else {
            InputStream in = null;
            OutputStream out = null;
            try {
                in = new FileInputStream(source);
                out = new FileOutputStream(destination);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = in.read(buffer)) > 0) {
                    out.write(buffer, 0, length);
                }
            } catch (Exception e) {
                try {
                    in.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                try {
                    out.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    public static boolean deleteDirectory(String fullPath) {

        File path = new File(fullPath);

        if (path.exists()) {
            File[] files = path.listFiles();
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isDirectory()) {
                        deleteDirectory(files[i].getPath());
                    } else {
                        files[i].delete();
                    }
                }
            }
        }
        return (path.delete());
    }

    public static boolean deleteFile(String filePath) {
        try {
            File file = new File(filePath);
            if (file.delete()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static HashMap<String, Object> getDirectoryList(String dir) {
        String path = "";
        if (!MGLStringUtils.IsNullOrBlank(dir)) {
            path = dir;
            File f = new File(path);
            if (!f.exists() || f.isFile())
                path = "";
        }
        return listDirectory(path);
    }

    public static HashMap<String, Object> listDirectory(String dirPath) {
        HashMap<String, Object> results = new HashMap<String, Object>(1);
        List<HashMap> list = new ArrayList<HashMap>(1);
        if (MGLStringUtils.IsNullOrBlank(dirPath))
            dirPath = Constants.UploadHelpers.POST_FILE;
        File[] files = new File(dirPath).listFiles();
        if (files != null) {
            for (File file : files) {
                HashMap<String, String> map = new HashMap<String, String>(1);

                String extension = "";
                int index = file.getName().lastIndexOf('.');
                if (index >= 0) extension = file.getName().substring(index + 1);
                if (MGLStringUtils.IsNullOrBlank(extension)) extension = "file";
                String type = file.isDirectory() ? "dir" : extension;
                map.put(type, file.getAbsolutePath());
                list.add(map);
            }
            results.put("data", list);
        }
        return results;
    }

    public static boolean saveFile(String file, String str) throws IOException {
        byte dataToWrite[] = str.getBytes();
        FileOutputStream out = new FileOutputStream(file);
        out.write(dataToWrite);
        out.close();
        return true;
    }

    public static String checkDirs(String path) {
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
            dir.setReadable(true, false);
            dir.setExecutable(true, false);
            dir.setWritable(true, false);
        }
        return dir.getAbsolutePath();
    }

    public static String readFile(String path, Charset encoding) throws IOException {
        try {
            byte[] encoded = Files.readAllBytes(Paths.get(path));
            return new String(encoded, encoding);
        } catch (IOException e) {
        }
        return "";
    }

    public static boolean limitFileSize(MultipartFile[] files) {
        for (MultipartFile file : files) {
            long fileSizeInBytes = file.getSize();
            long fileSizeInKB = fileSizeInBytes / 1024;
            long fileSizeInMB = fileSizeInKB / 1024;
            if (fileSizeInMB > 20) {
                return false;
            }
        }
        return true;
    }

    public static boolean isValidObjectPath(String objectName) {
        if (MGLStringUtils.IsNullOrBlank(objectName)) return false;
        return Arrays.asList(Constants.VALID_OBJECT_NAMES).contains(objectName);
    }

    public static boolean isValidExtension(String ext) {
        if (MGLStringUtils.IsNullOrBlank(ext)) return false;
        return Arrays.asList(Constants.VALID_EXTENSIONS).contains(ext.toLowerCase());
    }

}
