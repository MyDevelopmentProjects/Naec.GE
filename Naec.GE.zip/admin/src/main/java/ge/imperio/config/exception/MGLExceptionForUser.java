package ge.imperio.config.exception;

import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 * Created by vasho on 16.04.2016.
 */
public class MGLExceptionForUser extends UsernameNotFoundException {
    public MGLExceptionForUser(String msg) {
        super(msg);
    }
}
