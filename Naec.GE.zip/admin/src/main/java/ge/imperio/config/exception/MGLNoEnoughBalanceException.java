package ge.imperio.config.exception;

/**
 * Created by vasho on 16.04.2016.
 */
public class MGLNoEnoughBalanceException extends MGLException {

    public MGLNoEnoughBalanceException(String message) {
        super(message);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }

}
