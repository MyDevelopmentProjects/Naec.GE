package ge.imperio.config.core;

import ge.imperio.utils.RequestResponse;
import ge.imperio.utils.MGLStringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import static ge.imperio.utils.constants.Constants.ErrorCodes.ErrorResponse.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

@ControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    private static final String CONTROLLER = "ge.imperio.controller";

    @ExceptionHandler(value = {Throwable.class, RuntimeException.class})
    @ResponseBody
    public RequestResponse unCaughtErrorHandler(Throwable e) {
        logger.error("UnHandled Exception has occurred", e);
        return this.generateErrorReport(e);
    }

    private void test(String x){
    }
    private void test(int a){
    }

    private RequestResponse generateErrorReport(Throwable e) {
        RequestResponse response = new RequestResponse();
        response.setCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        response.setSuccess(false);
        response.setExceptionMessage(this.parseStack(e.getStackTrace()));
        switch (e.getClass().getCanonicalName()) {
            case "org.springframework.security.access.AccessDeniedException":
                response.setErrorMessage(ACCESS_IS_DENIED);
                break;
            case "javax.persistence.PersistenceException":
                String message = e.getMessage();
                if (message != null && message.contains("ConstraintViolationException"))
                    response.setErrorMessage(DUPLICATE_RECORD);
                else response.setErrorMessage(PERSISTENCE_EXCEPTION);
                break;
            case "org.springframework.dao.DataIntegrityViolationException":
                response.setErrorMessage(RECORD_IS_USED_IN_OTHER_TABLES);
                break;
            case "ge.imperio.config.exception.MGLNoEnoughBalanceException":
            case "ge.imperio.config.exception.MGLException":
            case "ge.imperio.config.exception.MGLExceptionForUser":
                response.setErrorMessage(e.getMessage());
                break;
            default:
                response.setErrorMessage(UNKNOWN);
                break;
        }
        String stack = ExceptionUtils.getStackTrace(e);
        response.setExceptionMessage(stack);
        return response;
    }

    private String parseStack(StackTraceElement[] stackTraceElements) {
        HashMap<String, Object> parseElements = new HashMap<>(2);
        if (stackTraceElements != null && stackTraceElements.length < 25) {
            for (StackTraceElement el : stackTraceElements) {
                if (el.getClassName().contains(CONTROLLER)) {
                    parseElements.put("class", MGLStringUtils.substringUpToFirstOccurance(el.getClassName(), '$'));
                    parseElements.put("method", el.getMethodName());
                    break;
                }
            }
            try {
                return new ObjectMapper().writeValueAsString(parseElements);
            } catch (IOException e) {
                return "";
            }
        }
        return "";
    }
}