package ge.imperio.dao;

import ge.imperio.model.Categories;
import ge.imperio.model.Slider;
import ge.imperio.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Repository
public class SliderDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Slider save(Slider slider) {
        if (slider.getId() != null) {
            em.merge(slider);
        } else {
            em.persist(slider);
        }
        return slider;
    }

    public void delete(Long id) {
        Slider slider = em.find(Slider.class, id);
        em.remove(slider);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Slider.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}