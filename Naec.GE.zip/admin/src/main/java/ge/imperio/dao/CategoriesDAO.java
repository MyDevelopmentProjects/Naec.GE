package ge.imperio.dao;

import ge.imperio.model.Categories;
import ge.imperio.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CategoriesDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Categories save(Categories service) {
        if (service.getId() != null) {
            em.merge(service);
        } else {
            em.persist(service);
        }
        return service;
    }

    public void delete(Long id) {
        Categories service = em.find(Categories.class, id);
        em.remove(service);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Categories.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}