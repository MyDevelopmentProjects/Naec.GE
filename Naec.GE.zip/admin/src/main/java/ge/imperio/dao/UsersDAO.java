package ge.imperio.dao;

import ge.imperio.config.exception.MGLExceptionForUser;
import ge.imperio.model.Users;
import ge.imperio.utils.constants.Constants;
import ge.imperio.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UsersDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @SuppressWarnings("unchecked")
    public Users findByUserName(String username) throws MGLExceptionForUser {
        List<Users> users;
        users = em.createQuery("from Users where userName=:username")
                .setParameter("username", username)
                .getResultList();
        if (users != null && users.size() > 0) {
            return users.get(0);
        }
        throw new MGLExceptionForUser(Constants.ErrorCodes.ErrorMessages.INCORRECT_CREDS);
    }

    public Users saveUser(Users user) {
        if (user.getId() != null) {
            em.merge(user);
        } else {
            em.persist(user);
        }
        return user;
    }

    public void deleteUser(Long id) {
        Users user = em.find(Users.class, id);
        em.remove(user);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Users.class) {
            fieldList.add("username");
            fieldList.add("last_name");
            fieldList.add("first_name");
            fieldList.add("email");
            fieldList.add("phone");
            fieldList.add("pid");
            fieldList.add("dateCreated");
            fieldList.add("dob");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }
}