package ge.imperio.dao;

import ge.imperio.model.Categories;
import ge.imperio.model.Gallery;
import ge.imperio.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class GalleryDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Gallery save(Gallery gallery) {
        if (gallery.getId() != null) {
            em.merge(gallery);
        } else {
            em.persist(gallery);
        }
        return gallery;
    }

    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {
        Predicate pdqExpr = null;
        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Gallery> criteriaQuery = criteriaBuilder.createQuery(Gallery.class);
        Root<Gallery> returnClassRoot = criteriaQuery.from(Gallery.class);
        returnClassRoot.alias(TABLE_ALIAS);
        boolean isVideo =   false;
        if (objects != null && objects.length > 0 && objects[0] instanceof Boolean) {
            isVideo = (boolean) objects[0];
        }
        pdqExpr = criteriaBuilder.equal(returnClassRoot.get("video"), isVideo);
        return pdqExpr;
    }

    public void delete(Long id) {
        Gallery gallery = em.find(Gallery.class, id);
        em.remove(gallery);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        return new ArrayList<>();
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}