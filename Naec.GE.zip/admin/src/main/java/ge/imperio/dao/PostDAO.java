package ge.imperio.dao;

import ge.imperio.model.Categories;
import ge.imperio.model.Post;
import ge.imperio.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class PostDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Post save(Post post) {
        Date dateCreated = post.getDateCreated();
        if (post.getId() != null) {
            em.merge(post);
            Post p = em.find(Post.class, post.getId());
            if (p.getDateCreated() != dateCreated) {
                updateEventDate(post, dateCreated);
            }
        } else {
            em.persist(post);
        }
        return post;
    }

    void updateEventDate(Post post, Date date) {
        try {
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            String dateString = df.format(date);
            String sql = String.format("UPDATE post SET dateCreated = '%s' WHERE id = %d", dateString, post.getId());
            em.createNativeQuery(sql).executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void levelUp(Long id) {
        Post post = em.find(Post.class, id);
        post.setDateUpdated(new Date());
        em.merge(post);
    }

    public void delete(Long id) {
        Post post = em.find(Post.class, id);
        em.remove(post);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Post.class) {
            fieldList.add("name");
            fieldList.add("desc");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}