package ge.imperio.dao;

import ge.imperio.model.Permissions;
import ge.imperio.utils.MGLUserUtils;
import ge.imperio.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class PermissionsDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {
        Predicate pdqExpr = null;
        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Permissions> criteriaQuery = criteriaBuilder.createQuery(Permissions.class);
        Root<Permissions> returnClassRoot = criteriaQuery.from(Permissions.class);
        returnClassRoot.alias(TABLE_ALIAS);
        return pdqExpr;
    }



    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Permissions.class) {
            fieldList.add("name");
            fieldList.add("description");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}