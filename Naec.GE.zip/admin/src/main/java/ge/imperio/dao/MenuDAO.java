package ge.imperio.dao;

import ge.imperio.model.Menu;
import ge.imperio.model.Post;
import ge.imperio.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Repository
public class MenuDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Menu save(Menu menu) {
        if (menu.getId() != null) {
            em.merge(menu);
        } else {
            em.persist(menu);
        }
        return menu;
    }

    public void delete(Long id) {
        Menu menu = em.find(Menu.class, id);
        em.remove(menu);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        return new ArrayList<String>();
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }


    public List<Menu> getMenuByLang(boolean isEnglish) {
        List<Menu> menu = em.createQuery("from Menu WHERE english = :isEnglish")
                .setParameter("isEnglish", isEnglish)
                .getResultList();
        if (menu != null && menu.size() > 0) {
            return menu;
        }
        return new ArrayList<>(0);
    }

}