package ge.imperio.service;

import ge.imperio.dao.MenuDAO;
import ge.imperio.model.Menu;
import ge.imperio.dto.MenuDTO;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
public class MenuService {

    @Autowired
    private MenuDAO menuDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<MenuDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return menuDAO.getPaginatedResultList(Menu.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(MenuDTO.class);
    }

    public List<Menu> getMenuByLang(boolean isEnglish) {
        return menuDAO.getMenuByLang(isEnglish);
    }

    @Transactional
    public void save(Menu menu) {
        menuDAO.save(menu);
    }

    @Transactional
    public void delete(Long id) {
        menuDAO.delete(id);
    }
}
