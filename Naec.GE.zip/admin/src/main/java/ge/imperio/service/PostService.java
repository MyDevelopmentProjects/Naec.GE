package ge.imperio.service;

import ge.imperio.dao.PostDAO;
import ge.imperio.dto.PostDTO;
import ge.imperio.model.Post;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PostService {

    @Autowired
    private PostDAO postDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<PostDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return postDAO.getPaginatedResultList(Post.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(PostDTO.class);
    }

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<PostDTO> getList() {
        return postDAO.getPaginatedResultList(Post.class, "",
                "", false, 0, -255).transform(PostDTO.class);
    }

    @Transactional
    public void levelUp(Long id){
        postDAO.levelUp(id);
    }

    @Transactional
    public Post save(Post post) {
        return postDAO.save(post);
    }

    @Transactional
    public void delete(Long id) {
        postDAO.delete(id);
    }

}
