package ge.imperio.service;

import ge.imperio.dao.PermissionsDAO;
import ge.imperio.dto.PermissionsDTO;
import ge.imperio.model.Permissions;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PermissionsService {

    @Autowired
    private PermissionsDAO permissionsDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<PermissionsDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return permissionsDAO.getPaginatedResultList(Permissions.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(PermissionsDTO.class);
    }

}
