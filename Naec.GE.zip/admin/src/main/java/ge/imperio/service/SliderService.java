package ge.imperio.service;

import ge.imperio.dao.SliderDAO;
import ge.imperio.dto.SliderDTO;
import ge.imperio.model.Slider;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SliderService {

    @Autowired
    private SliderDAO sliderDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<SliderDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return sliderDAO.getPaginatedResultList(Slider.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(SliderDTO.class);
    }

    @Transactional
    public Slider save(Slider slider) {
        return sliderDAO.save(slider);
    }

    @Transactional
    public void delete(Long id) {
        sliderDAO.delete(id);
    }

}
