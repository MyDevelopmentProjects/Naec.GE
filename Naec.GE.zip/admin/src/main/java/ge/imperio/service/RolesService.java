package ge.imperio.service;

import ge.imperio.dao.RolesDAO;
import ge.imperio.dto.RolesDTO;
import ge.imperio.model.Roles;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RolesService {

    @Autowired
    private RolesDAO rolesDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<RolesDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return rolesDAO.getPaginatedResultList(Roles.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(RolesDTO.class);
    }

    @Transactional(readOnly = true)
    public List getRolePermissions(long roleId) {
        return rolesDAO.getRolePermissionsByRoleId(roleId);
    }

    @Transactional
    public boolean saveRolePermission(String json) {
        rolesDAO.saveRolePermission(json);
        return true;
    }

    @Transactional
    public boolean saveRole(Roles role) {
        rolesDAO.saveRole(role);
        return true;
    }

    @Transactional
    public boolean deleteRole(Long id) {
        rolesDAO.deleteRole(id);
        return true;
    }

}
