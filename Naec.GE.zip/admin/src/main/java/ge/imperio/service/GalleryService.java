package ge.imperio.service;

import ge.imperio.dao.CategoriesDAO;
import ge.imperio.dao.GalleryDAO;
import ge.imperio.dto.CategoriesDTO;
import ge.imperio.dto.GalleryDTO;
import ge.imperio.model.Categories;
import ge.imperio.model.Gallery;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class GalleryService {

    @Autowired
    private GalleryDAO galleryDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<GalleryDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize, boolean isGallery) {
        return galleryDAO.getPaginatedResultList(Gallery.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize, isGallery).transform(GalleryDTO.class);
    }

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<GalleryDTO> getList(boolean isGallery) {
        return galleryDAO.getPaginatedResultList(Gallery.class, "",
                "", false, 0, -255, isGallery).transform(GalleryDTO.class);
    }

    @Transactional
    public Gallery save(Gallery gallery) {
        return galleryDAO.save(gallery);
    }

    @Transactional
    public void delete(Long id) {
        galleryDAO.delete(id);
    }

}
