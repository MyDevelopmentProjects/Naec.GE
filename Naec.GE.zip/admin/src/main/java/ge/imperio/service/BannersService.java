package ge.imperio.service;

import ge.imperio.dao.BannersDAO;
import ge.imperio.dto.BannersDTO;
import ge.imperio.model.Banners;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BannersService {

    @Autowired
    private BannersDAO bannersDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<BannersDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return bannersDAO.getPaginatedResultList(Banners.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(BannersDTO.class);
    }

    @Transactional
    public Banners saveBanner(Banners banner) {
        return bannersDAO.saveBanner(banner);
    }

    @Transactional
    public void deleteBanner(Long id) {
        bannersDAO.deleteBanner(id);
    }

}
