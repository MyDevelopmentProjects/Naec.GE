package ge.imperio.service;

import ge.imperio.dao.CategoriesDAO;
import ge.imperio.dto.CategoriesDTO;
import ge.imperio.model.Categories;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CategoriesService {

    @Autowired
    private CategoriesDAO categoriesDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return categoriesDAO.getPaginatedResultList(Categories.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(CategoriesDTO.class);
    }

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList() {
        return categoriesDAO.getPaginatedResultList(Categories.class, "",
                "", false, 0, -255).transform(CategoriesDTO.class);
    }

    @Transactional
    public Categories saveService(Categories services) {
        return categoriesDAO.save(services);
    }

    @Transactional
    public void deleteService(Long id) {
        categoriesDAO.delete(id);
    }

}
