package ge.imperio.service;

import ge.imperio.dao.UsersDAO;
import ge.imperio.dto.UsersDTO;
import ge.imperio.model.Users;
import ge.imperio.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UsersService {

    @Autowired
    private UsersDAO usersDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<UsersDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return usersDAO.getPaginatedResultList(Users.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(UsersDTO.class);
    }

    @Transactional
    public Users saveUser(Users user) {
        return usersDAO.saveUser(user);
    }

    @Transactional
    public void deleteUser(Long id) {
        usersDAO.deleteUser(id);
    }

}
