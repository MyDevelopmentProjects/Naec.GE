package ge.imperio.model;

import ge.imperio.mappedsupperclass.SuperModel;

import javax.persistence.*;

@Entity
@Table(name = "post", catalog = "naec")
public class Post extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id", nullable = true)
    private Categories category;

    @Column(name = "name", columnDefinition = "VARCHAR(300) COLLATE utf8mb4_unicode_ci", nullable = false)
    private String name;

    @Column(name = "description", columnDefinition = "longtext COLLATE utf8mb4_unicode_ci", nullable = false)
    private String desc;

    @Column(name = "image", nullable = true)
    private String image;

    @Column(name = "images", nullable = true)
    private String images;

    @Column(name = "video", nullable = true)
    private String video;

    @Column(name = "is_english", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean english = false;

    @Column(name = "is_active", nullable = false, columnDefinition = "bit(1) DEFAULT 1")
    private boolean active = true;

    @Column(name = "is_special", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean special = false;

    @Column(name = "requiresAuth", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean requiresAuth = false;

    @Column(name = "front_desc", columnDefinition = "longtext COLLATE utf8mb4_unicode_ci")
    private String frontDesc;

    @Column(name = "isFront", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean front = false;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Categories getCategory() {
        return category;
    }

    public void setCategory(Categories category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean getEnglish() {
        return english;
    }

    public void setEnglish(boolean english) {
        this.english = english;
    }

    public boolean getSpecial() {
        return special;
    }

    public void setSpecial(boolean special) {
        this.special = special;
    }

    public boolean getRequiresAuth() {
        return requiresAuth;
    }

    public void setRequiresAuth(boolean requiresAuth) {
        this.requiresAuth = requiresAuth;
    }

    public boolean getFront() {
        return front;
    }

    public void setFront(boolean front) {
        this.front = front;
    }

    public String getFrontDesc() {
        return frontDesc;
    }

    public void setFrontDesc(String frontDesc) {
        this.frontDesc = frontDesc;
    }
}
