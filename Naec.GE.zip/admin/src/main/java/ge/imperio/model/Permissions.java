package ge.imperio.model;

import ge.imperio.mappedsupperclass.SuperModel;
import org.codehaus.jackson.annotate.JsonBackReference;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonManagedReference;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Entity
@Table(name = "permissions", catalog = "naec")
public class Permissions extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(min = 3, max = 50)
    @Column(name = "name", unique = true, nullable = false)
    private String name;

    @Column(name = "description", unique = true, nullable = true)
    private String description;

    @Column(name = "is_super_admin", nullable = false)
    private byte isSuperAdmin = 0;

    /*************************************
     * Getters & Setters
     ***************************************************/
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte getIsSuperAdmin() {
        return isSuperAdmin;
    }

    public void setIsSuperAdmin(byte isSuperAdmin) {
        this.isSuperAdmin = isSuperAdmin;
    }

    /*************************************Getters & Setters***************************************************/

}
