package ge.imperio.model;

import ge.imperio.mappedsupperclass.SuperModel;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "banners", catalog = "naec")
public class Banners extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "position", nullable = false)
    private byte position = 0;

    @Column(name = "img_url")
    private String imgURL;

    @Column(name = "frame_url")
    private String frameURL;

    @Column(name = "href")
    private String href;

    @Column(name = "name", columnDefinition = "VARCHAR(500) COLLATE utf8mb4_unicode_ci", nullable = true)
    private String name;

    @Column(name = "is_active", columnDefinition = "bit(1) DEFAULT 0")
    private Boolean active = false;

    @Column(name = "is_english", columnDefinition = "bit(1) DEFAULT 0")
    private Boolean english = false;

    @Column(name = "bottom", columnDefinition = "bit(1) DEFAULT 0")
    private Boolean bottom = false;

    @Column(name = "top", columnDefinition = "bit(1) DEFAULT 0")
    private Boolean top = false;

    /*************************************Getters & Setters***************************************************/
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public byte getPosition() {
        return position;
    }

    public void setPosition(byte position) {
        this.position = position;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    public String getFrameURL() {
        return frameURL;
    }

    public void setFrameURL(String frameURL) {
        this.frameURL = frameURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public Boolean getEnglish() {
        return english;
    }

    public void setEnglish(Boolean english) {
        this.english = english;
    }

    public Boolean getBottom() {
        return bottom;
    }

    public void setBottom(Boolean bottom) {
        this.bottom = bottom;
    }

    public Boolean getTop() {
        return top;
    }

    public void setTop(Boolean top) {
        this.top = top;
    }

    /*************************************Getters & Setters***************************************************/

}
