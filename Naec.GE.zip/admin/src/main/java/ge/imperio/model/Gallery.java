package ge.imperio.model;

import ge.imperio.mappedsupperclass.SuperModel;

import javax.persistence.*;

@Entity
@Table(name = "gallery", catalog = "naec")
public class Gallery extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name", columnDefinition = "VARCHAR(50) COLLATE utf8mb4_unicode_ci", nullable = false)
    private String name;

    @Column(name = "images", columnDefinition = "text COLLATE utf8mb4_unicode_ci", nullable = false)
    private String images;

    @Column(name = "is_video", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean video = false;

    @Column(name = "is_english", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean english = false;

    /*************************************Getters & Setters***************************************************/
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getImages() {
        return images;
    }
    public void setImages(String images) {
        this.images = images;
    }
    public boolean getVideo() {
        return video;
    }
    public void setVideo(boolean video) {
        this.video = video;
    }

    public boolean getEnglish() {
        return english;
    }

    public void setEnglish(boolean english) {
        this.english = english;
    }
    /*************************************Getters & Setters***************************************************/
}
