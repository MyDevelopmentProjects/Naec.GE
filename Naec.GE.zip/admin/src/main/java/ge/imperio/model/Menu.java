package ge.imperio.model;

import javax.persistence.*;


@Entity
@Table(name = "menu", catalog = "naec")
public class Menu {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "parent_id", nullable = true)
    private Long parentId = null;

    @Column(name = "name", columnDefinition = "VARCHAR(300) COLLATE utf8mb4_unicode_ci", nullable = false)
    private String name;

    @Column(name = "href", nullable = true)
    private String href;

    @Column(name = "is_english", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean english = false;

    @Column(name = "is_active", nullable = false, columnDefinition = "bit(1) DEFAULT 1")
    private boolean active = true;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public boolean getEnglish() {
        return english;
    }

    public void setEnglish(boolean english) {
        this.english = english;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
