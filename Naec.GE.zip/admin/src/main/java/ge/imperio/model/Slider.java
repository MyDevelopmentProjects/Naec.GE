package ge.imperio.model;

import ge.imperio.mappedsupperclass.SuperModel;

import javax.persistence.*;

@Entity
@Table(name = "slider", catalog = "naec")
public class Slider extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    //0 image if 1 video
    @Column(name = "type", nullable = false)
    private byte type = 0;

    private int position;

    @Column(name = "path", columnDefinition = "longtext COLLATE utf8mb4_unicode_ci", nullable = false)
    private String path;

    @Column(name = "title", columnDefinition = "VARCHAR(300) COLLATE utf8mb4_unicode_ci", nullable = false)
    private String title;

    @Column(name = "content", columnDefinition = "longtext COLLATE utf8mb4_unicode_ci", nullable = false)
    private String content;

    @Column(name = "url", columnDefinition = "longtext COLLATE utf8mb4_unicode_ci", nullable = false)
    private String url;

    @Column(name = "is_english", nullable = false, columnDefinition = "bit(1) DEFAULT 0")
    private boolean english = false;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public byte getType() {
        return type;
    }
    public void setType(byte type) {
        this.type = type;
    }
    public int getPosition() {
        return position;
    }
    public void setPosition(int position) {
        this.position = position;
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isEnglish() {
        return english;
    }

    public void setEnglish(boolean english) {
        this.english = english;
    }
}
