package ge.imperio.dto;

import ge.imperio.mappedsupperclass.SuperDTO;
import java.util.Date;

public class UsersDTO extends SuperDTO  {

    private Long id;
    private RolesDTO role;
    private String userName;
    private String password;
    private String firstName;
    private String lastName;
    private String email;
    private Date dob;
    private String pid;
    private String phone;
    private boolean active = false;
    private boolean salaryCreated;

    public UsersDTO() {
    }

    public UsersDTO(UsersDTO user) {
        this.id = user.id;
        this.userName = user.userName;
        this.password = user.password;
        this.email = user.email;
        this.firstName = user.firstName;
        this.lastName = user.lastName;
        this.phone = user.phone;
        this.role = user.role;
        this.dob = user.dob;
        this.pid = user.pid;
        this.active = user.active;
        this.dateCreated = user.dateCreated;
        this.dateUpdated = user.dateUpdated;
        this.dateDeleted = user.dateDeleted;
        this.salaryCreated = user.salaryCreated;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public RolesDTO getRole() {
        return role;
    }

    public void setRole(RolesDTO role) {
        this.role = role;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean getSalaryCreated() {
        return salaryCreated;
    }

    public void setSalaryCreated(boolean salaryCreated) {
        this.salaryCreated = salaryCreated;
    }

}
